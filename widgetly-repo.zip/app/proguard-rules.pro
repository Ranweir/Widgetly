# Widgetly: nothing special to keep. Manifest components are kept automatically.
-dontwarn kotlin.**
