package com.widgetly.app.ui

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * Glass + light neon glow building blocks.
 * The glow is a BRIGHT halo (accent lifted towards white), never a dark shadow.
 */

/** Brighter, luminous version of the accent used for all glows. */
fun glowColor(accent: Color): Color = lerp(accent, Color.White, 0.25f)

internal fun Color.a(alpha: Float): Color = copy(alpha = alpha.coerceIn(0f, 1f))

/** Bright bloom + thin hot line sitting on a bottom edge (like the kit's under-glow). */
internal fun DrawScope.bottomBloom(
    color: Color,
    strength: Float,
    cx: Float,
    y: Float,
    halfWidth: Float,
    bloomHeight: Float
) {
    if (halfWidth <= 0f) return
    withTransform({ scale(1f, bloomHeight / halfWidth, Offset(cx, y)) }) {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(color.a(0.75f * strength), color.a(0f)),
                center = Offset(cx, y),
                radius = halfWidth
            ),
            radius = halfWidth,
            center = Offset(cx, y)
        )
    }
    val lineHalf = halfWidth * 0.8f
    drawRect(
        brush = Brush.horizontalGradient(
            colors = listOf(color.a(0f), color.a(strength), color.a(0f)),
            startX = cx - lineHalf,
            endX = cx + lineHalf
        ),
        topLeft = Offset(cx - lineHalf, y - 1.dp.toPx()),
        size = Size(lineHalf * 2f, 2.dp.toPx())
    )
}

/**
 * Light halo around a rounded rectangle: many soft strokes that fade outwards,
 * plus an optional bright streak along the bottom edge.
 */
fun Modifier.neonGlow(
    color: Color,
    corner: Dp,
    spread: Dp = 14.dp,
    strength: Float = 1f,
    streak: Boolean = true,
    stack: Boolean = false
): Modifier = drawBehind {
    val r = corner.toPx()
    val s = spread.toPx()

    if (stack) {
        val o = 6.dp.toPx()
        drawRoundRect(
            color = Color.White.a(0.035f),
            topLeft = Offset(o, o),
            size = size,
            cornerRadius = CornerRadius(r)
        )
        drawRoundRect(
            color = color.a(0.35f),
            topLeft = Offset(o, o),
            size = size,
            cornerRadius = CornerRadius(r),
            style = Stroke(1.dp.toPx())
        )
    }

    val layers = 9
    for (i in layers downTo 1) {
        val t = i / layers.toFloat()
        val grow = s * t
        val a = 0.15f * strength * (1f - t) * (1f - t) + 0.02f * strength
        drawRoundRect(
            color = color.a(a),
            topLeft = Offset(-grow, -grow + s * 0.25f),
            size = Size(size.width + grow * 2f, size.height + grow * 2f),
            cornerRadius = CornerRadius(r + grow),
            style = Stroke(s / layers * 2.4f)
        )
    }
    if (streak) {
        bottomBloom(
            color = color,
            strength = strength.coerceAtMost(1.2f),
            cx = size.width / 2f,
            y = size.height,
            halfWidth = size.width * 0.42f,
            bloomHeight = s * 0.9f
        )
    }
}

/** Frosted glass panel with a glowing, gradient edge. */
fun Modifier.glass(
    corner: Dp,
    glow: Color,
    strength: Float = 1f,
    spread: Dp = 14.dp,
    streak: Boolean = true,
    stack: Boolean = false,
    tint: Float = 0.08f
): Modifier {
    val shape = RoundedCornerShape(corner)
    return this
        .neonGlow(glow, corner, spread, strength, streak, stack)
        .clip(shape)
        .background(Color(0xFF111219).a(0.92f))
        .background(
            Brush.verticalGradient(
                listOf(Color.White.a(0.10f), Color.White.a(0.03f), glow.a(tint))
            )
        )
        .border(
            1.dp,
            Brush.verticalGradient(
                listOf(Color.White.a(0.30f), Color.White.a(0.08f), glow.a(0.95f))
            ),
            shape
        )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    strength: Float = 0.8f,
    content: @Composable ColumnScope.() -> Unit
) {
    val glow = glowColor(MaterialTheme.colorScheme.primary)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .glass(24.dp, glow, strength, stack = true)
            .padding(18.dp),
        content = content
    )
}

/** Primary = strongly glowing, tinted pill. Secondary = quiet glass pill. */
@Composable
fun GlowButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true
) {
    val glow = glowColor(MaterialTheme.colorScheme.primary)
    Box(
        modifier = modifier
            .height(52.dp)
            .glass(
                corner = 26.dp,
                glow = glow,
                strength = if (primary) 1.3f else 0.3f,
                spread = if (primary) 18.dp else 10.dp,
                tint = if (primary) 0.38f else 0.06f
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 24.dp),
            color = Color.White,
            fontWeight = FontWeight.Medium,
            style = MaterialTheme.typography.titleMedium
        )
    }
}

/** Segmented tabs like the kit: the selected segment glows from its bottom edge. */
@Composable
fun GlowSegmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val glow = glowColor(MaterialTheme.colorScheme.primary)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .glass(24.dp, glow, strength = 0.35f, spread = 10.dp, streak = false)
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .drawBehind {
                        if (on) {
                            drawRect(Brush.verticalGradient(listOf(Color.Transparent, glow.a(0.18f))))
                            bottomBloom(glow, 1.2f, size.width / 2f, size.height, size.width * 0.55f, 16.dp.toPx())
                        }
                        if (i < options.lastIndex) {
                            drawRect(
                                Color.White.a(0.14f),
                                topLeft = Offset(size.width - 1.dp.toPx(), size.height * 0.28f),
                                size = Size(1.dp.toPx(), size.height * 0.44f)
                            )
                        }
                    }
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (on) Color.White else Color.White.a(0.62f),
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}

/** Kit-style toggle: glowing red track with a pale knob when on. */
@Composable
fun GlowSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    val glow = glowColor(accent)
    val x by animateDpAsState(if (checked) 28.dp else 4.dp, label = "knob")
    Box(
        modifier = Modifier
            .size(width = 56.dp, height = 32.dp)
            .then(if (checked) Modifier.neonGlow(glow, 16.dp, 12.dp, 1.1f, streak = false) else Modifier)
            .clip(CircleShape)
            .background(
                if (checked) Brush.verticalGradient(listOf(glow, accent))
                else Brush.verticalGradient(listOf(Color.White.a(0.12f), Color.White.a(0.06f)))
            )
            .border(1.dp, if (checked) glow else Color.White.a(0.22f), CircleShape)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onCheckedChange)
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = x)
                .size(24.dp)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.White, if (checked) Color(0xFFE8E8EE) else Color(0xFFB4B6C4))
                    )
                )
        )
    }
}
