package com.widgetly.app

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.widgetly.app.ui.WidgetlyTheme

/**
 * Settings for one calendar widget: style, colours, opacity, text size, events, week start.
 * Opens when a widget is added (on launchers that ask) and from the widget's "Reconfigure" menu.
 */
class CalendarConfigActivity : ComponentActivity() {

    private val bgColors = listOf(
        0xFFFFFFFF, 0xFFF5E9D4, 0xFFDCEBFF, 0xFFFFE4E6, 0xFF334155, 0xFF1C1D26,
        0xFF000000, 0xFF14213D, 0xFF1E1B4B, 0xFF3B0764, 0xFF4C0519, 0xFF14532D
    ).map { it.toInt() }

    private val inkColors = listOf(
        0xFFFFFFFF, 0xFF14141F, 0xFFCBD5E1, 0xFFFF4D5E, 0xFFFF8A3D, 0xFFFFD23F,
        0xFF34D399, 0xFF2DD4BF, 0xFF4F8CFF, 0xFF8B7CF6, 0xFFFF6FB5, 0xFFA3E635
    ).map { it.toInt() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        setResult(RESULT_CANCELED)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        // A photo widget's "Reconfigure" is the photo picker.
        if (Prefs.slotType(this, widgetId) == Slots.TYPE_PHOTO) {
            startActivity(
                Intent(this, ImageConfigActivity::class.java)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            )
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
            finish()
            return
        }

        val mgr = AppWidgetManager.getInstance(this)
        val startStyle = CalendarRenderer.styleOf(this, mgr, widgetId)
        val cu = Prefs.custom(this, widgetId)
        val raw = Prefs.customRaw(this, widgetId)

        setContent {
            WidgetlyTheme(accent = Color(Prefs.ACCENTS[Prefs.accentIndex(this)])) {
                var style by remember { mutableIntStateOf(startStyle) }
                var bg by remember { mutableStateOf(cu.bg) }
                var text by remember { mutableStateOf(cu.text) }
                var today by remember { mutableStateOf(cu.today) }
                var opacity by remember { mutableFloatStateOf(if (raw[0] in 0..100) raw[0].toFloat() else 100f) }
                var sizeIdx by remember { mutableIntStateOf(raw[1].coerceIn(0, 2)) }
                var events by remember { mutableStateOf(raw[2] == 1) }
                var monday by remember { mutableIntStateOf(raw[3].coerceIn(-1, 1)) }

                fun save() {
                    Prefs.setSlotType(applicationContext, widgetId, Slots.TYPE_CAL)
                    Prefs.setCalStyle(applicationContext, widgetId, style)
                    Prefs.saveCustom(
                        applicationContext, widgetId, bg,
                        if (opacity.toInt() >= 100) -1 else opacity.toInt(),
                        text, today, sizeIdx, events, monday
                    )
                    CalendarRenderer.render(applicationContext, mgr, widgetId)
                    setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                    finish()
                }

                fun clearWidget() {
                    Slots.clear(applicationContext, widgetId)
                    SlotWidgetProvider.render(applicationContext, mgr, widgetId)
                    setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                    finish()
                }

                fun reset() {
                    bg = null; text = null; today = null; opacity = 100f
                    sizeIdx = 1; events = true; monday = -1
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0B0C12))
                        .systemBarsPadding()
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            "Customise widget",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Label("Style")
                        CalendarRenderer.NAMES.forEachIndexed { i, name ->
                            val sel = i == style
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (sel) Color(0x33FFFFFF) else Color(0x14FFFFFF))
                                    .clickable { style = i }
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(name, fontWeight = FontWeight.SemiBold, color = Color.White)
                                    Text(
                                        CalendarRenderer.DESCS[i],
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (sel) Text("✓", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }

                        Label("Background colour")
                        Swatches(bgColors, bg) { bg = it }

                        Label("Background opacity  ·  ${opacity.toInt()}%")
                        Slider(value = opacity, onValueChange = { opacity = it }, valueRange = 0f..100f)

                        Label("Text colour")
                        Swatches(inkColors, text) { text = it }

                        Label("Today highlight")
                        Swatches(inkColors, today) { today = it }

                        if (CalendarRenderer.hasTextSize(style)) {
                            Label("Text size")
                            Segmented(listOf("Small", "Normal", "Large"), sizeIdx) { sizeIdx = it }
                        }
                        if (CalendarRenderer.hasMonday(style)) {
                            Label("Week starts on")
                            Segmented(listOf("App setting", "Sunday", "Monday"), monday + 1) { monday = it - 1 }
                        }
                        if (CalendarRenderer.hasEvents(style)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Show today's events", color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "Only when the widget is tall enough",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(checked = events, onCheckedChange = { events = it })
                            }
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { reset() }) { Text("Reset") }
                        TextButton(onClick = { clearWidget() }) { Text("Empty it") }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { finish() }) { Text("Cancel") }
                        Button(onClick = { save() }) { Text("Save") }
                    }
                }
            }
        }
    }

    @Composable
    private fun Label(t: String) {
        Spacer(Modifier.height(6.dp))
        Text(t, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = Color.White)
    }

    /** First chip is "Auto" (null = keep the style's own colour). */
    @Composable
    private fun Swatches(colors: List<Int>, selected: Int?, onPick: (Int?) -> Unit) {
        val items: List<Int?> = listOf<Int?>(null) + colors
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items.chunked(7).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { c ->
                        val sel = c == selected
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(c?.let { Color(it) } ?: Color(0xFF2A2B38))
                                .border(
                                    BorderStroke(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color(0x44FFFFFF)),
                                    CircleShape
                                )
                                .clickable { onPick(c) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (c == null) Text("A", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun Segmented(options: List<String>, selected: Int, onPick: (Int) -> Unit) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x14FFFFFF)),
        ) {
            options.forEachIndexed { i, label ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (i == selected) Color(0x44FFFFFF) else Color.Transparent)
                        .clickable { onPick(i) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = Color.White, fontWeight = if (i == selected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}
