package com.widgetly.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews

/**
 * The one widget that shows up in the launcher's widget picker. It starts out empty; the app then
 * fills it with a calendar style or a photo (see [Slots]). What it shows is stored per widget id.
 */
class SlotWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { render(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?
    ) {
        render(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { Slots.forget(context, it) }
    }

    companion object {
        fun ids(c: Context): IntArray =
            AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, SlotWidgetProvider::class.java))

        fun updateAll(c: Context) {
            val mgr = AppWidgetManager.getInstance(c)
            ids(c).forEach { render(c, mgr, it) }
        }

        fun render(c: Context, mgr: AppWidgetManager, id: Int) {
            Slots.claimPending(c, id)
            when (Prefs.slotType(c, id)) {
                Slots.TYPE_PHOTO -> ImageWidgetProvider.update(c, mgr, id)
                Slots.TYPE_CAL -> CalendarRenderer.render(c, mgr, id)
                else -> renderEmpty(c, mgr, id)
            }
        }

        private fun renderEmpty(c: Context, mgr: AppWidgetManager, id: Int) {
            val rv = RemoteViews(c.packageName, R.layout.widget_slot)
            val open = PendingIntent.getActivity(
                c, id, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.slot_root, open)
            mgr.updateAppWidget(id, rv)
        }
    }
}

/** Puts a style or a photo into an empty widget. */
object Slots {
    const val TYPE_CAL = "cal"
    const val TYPE_PHOTO = "photo"

    /** Token for the photo widget; calendar styles use their index (>= 0). */
    const val PHOTO = -1

    enum class Outcome { APPLIED, PINNING, MANUAL }

    fun emptyIds(c: Context): List<Int> = SlotWidgetProvider.ids(c).filter { Prefs.slotType(c, it) == null }

    fun count(c: Context, photo: Boolean): Int {
        val want = if (photo) TYPE_PHOTO else TYPE_CAL
        return SlotWidgetProvider.ids(c).count { Prefs.slotType(c, it) == want }
    }

    /** Writes the choice for a widget without redrawing it. */
    private fun bind(c: Context, id: Int, token: Int) {
        Prefs.clearCalendar(c, id)
        if (token == PHOTO) {
            Prefs.setSlotType(c, id, TYPE_PHOTO)
        } else {
            Prefs.setSlotType(c, id, TYPE_CAL)
            Prefs.setCalStyle(c, id, token)
        }
    }

    /** Called from the app's Add buttons. */
    fun addFromApp(c: Context, token: Int): Outcome {
        val empty = emptyIds(c)
        if (empty.isNotEmpty()) {
            val id = empty.first()
            bind(c, id, token)
            SlotWidgetProvider.render(c, AppWidgetManager.getInstance(c), id)
            if (token == PHOTO) {
                // Let the user pick this widget's photo right away.
                c.startActivity(
                    Intent(c, ImageConfigActivity::class.java)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            return Outcome.APPLIED
        }
        // No empty widget on the home screen: ask the launcher to add one and fill it when it arrives.
        Prefs.setPending(c, token)
        return if (WidgetUpdater.requestPin(c, SlotWidgetProvider::class.java)) {
            Outcome.PINNING
        } else {
            Prefs.clearPending(c)
            Outcome.MANUAL
        }
    }

    /** Asks the launcher to add a plain empty widget. */
    fun pinEmpty(c: Context): Boolean {
        Prefs.clearPending(c)
        return WidgetUpdater.requestPin(c, SlotWidgetProvider::class.java)
    }

    /** A freshly added widget takes the style that was requested while no empty widget existed. */
    fun claimPending(c: Context, id: Int) {
        if (Prefs.slotType(c, id) != null) return
        val token = Prefs.takePending(c) ?: return
        bind(c, id, token)
    }

    fun clear(c: Context, id: Int) {
        Prefs.clearCalendar(c, id)
        Prefs.setSlotType(c, id, null)
    }

    fun forget(c: Context, id: Int) {
        clear(c, id)
        ImageStore.fileFor(c, id).delete()
    }
}
