package com.widgetly.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/**
 * Photos picked from the gallery are copied into the app's private storage,
 * so widgets keep working after the picker's temporary access expires.
 * widgetId == null means the app-wide default photo.
 */
object ImageStore {
    private const val MAX_SIDE = 1280

    fun fileFor(c: Context, widgetId: Int?): File =
        File(c.filesDir, if (widgetId == null) "img_default.jpg" else "img_$widgetId.jpg")

    fun save(c: Context, uri: Uri, widgetId: Int?): Boolean {
        return try {
            val bmp = decode(c, uri) ?: return false
            FileOutputStream(fileFor(c, widgetId)).use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, it)
            }
            bmp.recycle()
            true
        } catch (e: Exception) {
            false
        } catch (e: OutOfMemoryError) {
            false
        }
    }

    fun load(c: Context, widgetId: Int?): Bitmap? {
        val f = fileFor(c, widgetId)
        if (!f.exists()) return null
        return try {
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: Exception) {
            null
        }
    }

    /** The widget's own photo, or the default one if it has none. */
    fun loadForWidget(c: Context, widgetId: Int): Bitmap? =
        load(c, widgetId) ?: load(c, null)

    private fun decode(c: Context, uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (bounds.outWidth / (sample * 2) >= MAX_SIDE ||
            bounds.outHeight / (sample * 2) >= MAX_SIDE
        ) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null

        val degrees = try {
            c.contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }

        val scale = minOf(1f, MAX_SIDE.toFloat() / maxOf(raw.width, raw.height))
        if (degrees == 0f && scale >= 1f) return raw

        val m = Matrix().apply {
            postScale(scale, scale)
            postRotate(degrees)
        }
        val out = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        if (out !== raw) raw.recycle()
        return out
    }
}
