package com.widgetly.app

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.res.Configuration

object WidgetSize {
    /** Rough launcher cell count for a size in dp (a cell is ~70dp minus 30dp margin). */
    private fun cells(dp: Int) = ((dp + 30) / 70).coerceIn(1, 5)

    /** 2, 3 or 4. Picks the layout: 2x2 = compact, 3x3 = roomy, 4x4 = full. */
    fun sizeClass(mgr: AppWidgetManager, id: Int): Int {
        val o = mgr.getAppWidgetOptions(id)
        val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110)
        val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)
        return minOf(cells(w), cells(h)).coerceIn(2, 4)
    }

    /** Launcher cells (width, height) the widget currently takes. */
    fun cellsWH(mgr: AppWidgetManager, id: Int): Pair<Int, Int> {
        val o = mgr.getAppWidgetOptions(id)
        val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110)
        val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)
        return Pair(cells(w), cells(h))
    }

    class PxSize(val w: Int, val h: Int, val scale: Float)

    /** Pixel size a widget image should be drawn at; the longest side is capped for RemoteViews. */
    fun pixelSize(context: Context, mgr: AppWidgetManager, id: Int, cap: Int = 720): PxSize {
        val o = mgr.getAppWidgetOptions(id)
        val density = context.resources.displayMetrics.density
        val landscape = context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var wDp = o.getInt(
            if (landscape) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0
        )
        var hDp = o.getInt(
            if (landscape) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0
        )
        if (wDp <= 0) wDp = 110
        if (hDp <= 0) hDp = 110
        val w = wDp * density
        val h = hDp * density
        val s = minOf(1f, cap / maxOf(w, h))
        return PxSize(maxOf(1, (w * s).toInt()), maxOf(1, (h * s).toInt()), s)
    }
}

object WidgetUpdater {
    fun updateAll(c: Context) {
        CalendarWidgetProvider.updateAll(c)
        ImageWidgetProvider.updateAll(c)
        CalendarStyles.updateAll(c)
    }

    fun count(c: Context, cls: Class<*>): Int =
        AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, cls)).size

    /** Asks the launcher to pin the widget. Returns false if the launcher can't do it. */
    fun requestPin(c: Context, cls: Class<*>): Boolean {
        val mgr = AppWidgetManager.getInstance(c)
        return if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(c, cls), null, null)
            true
        } else {
            false
        }
    }
}
