package com.widgetly.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.widgetly.app.CalendarWidgetProvider
import com.widgetly.app.ImageStore
import com.widgetly.app.Slots
import com.widgetly.app.ImageWidgetProvider
import com.widgetly.app.Prefs
import com.widgetly.app.WidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

// ---------------------------------------------------------------- shared pieces

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 26.dp, top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        content = content
    )
}

@Composable
private fun ScreenTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium.copy(
                shadow = Shadow(
                    color = glowColor(MaterialTheme.colorScheme.primary).a(0.75f),
                    offset = Offset.Zero,
                    blurRadius = 28f
                )
            ),
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    GlassCard(content = content)
}

private fun hasCalendarPermission(ctx: Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) ==
        PackageManager.PERMISSION_GRANTED

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(onGo: (Int) -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val imageCount = remember(tick) { Slots.count(ctx, true) }
    val calendarCount = remember(tick) { Slots.count(ctx, false) }
    val emptyCount = remember(tick) { Slots.emptyIds(ctx).size }

    ScreenColumn {
        ScreenTitle("Widgetly", "Calendar and photo widgets for your home screen")

        SectionCard {
            Text("Empty widget", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Add the empty Widgetly widget to your home screen once. Then tap Add on any widget " +
                    "below and it fills that empty widget.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (emptyCount == 1) "1 empty widget waiting on your home screen"
                else "$emptyCount empty widgets waiting on your home screen",
                style = MaterialTheme.typography.labelMedium,
                color = glowColor(MaterialTheme.colorScheme.primary)
            )
            Spacer(Modifier.height(14.dp))
            GlowButton("Add empty widget", {
                if (!Slots.pinEmpty(ctx)) toastManual(ctx)
                tick++
            })
        }

        WidgetCard(
            title = "Photo widget",
            body = "Show a photo from your gallery. Works in every size from 2×2 to 4×4.",
            preview = com.widgetly.app.R.drawable.preview_photo,
            count = imageCount,
            onAdd = { addStyle(ctx, Slots.PHOTO) { tick++ } },
            onCustomize = { onGo(1) }
        )
        WidgetCard(
            title = "Calendar widget",
            body = "A month calendar with today highlighted. The 4×4 size also lists today's events.",
            preview = com.widgetly.app.R.drawable.preview_calendar,
            count = calendarCount,
            onAdd = { addStyle(ctx, 0) { tick++ } },
            onCustomize = { onGo(2) }
        )

        SectionCard {
            Text(
                "More calendar styles",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(6.dp))
            com.widgetly.app.CalendarStyles.LIST.forEach { style ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PreviewBox(style.preview, 84.dp, 64.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(style.name, fontWeight = FontWeight.Medium, color = Color.White)
                        Text(
                            style.desc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    GlowButton("Add", { addStyle(ctx, style.style) { tick++ } }, modifier = Modifier.width(64.dp), height = 38.dp)
                }
            }
        }

        SectionCard {
            Text(
                "How to add a widget",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Long-press your home screen, open Widgets, find Widgetly and drag the empty widget out. " +
                    "Then come back here and tap Add on the widget you want. To change a calendar widget's " +
                    "style, colours, opacity or text size later, long-press it and choose Reconfigure.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun toastManual(ctx: Context) {
    Toast.makeText(
        ctx,
        "Long-press your home screen, open Widgets and add the empty Widgetly widget first.",
        Toast.LENGTH_LONG
    ).show()
}

/** Fills an empty widget with this style, or asks the launcher for a new one if none is free. */
private fun addStyle(ctx: Context, token: Int, onDone: () -> Unit) {
    when (Slots.addFromApp(ctx, token)) {
        Slots.Outcome.APPLIED ->
            Toast.makeText(ctx, "Added to your empty widget", Toast.LENGTH_SHORT).show()
        Slots.Outcome.PINNING -> Unit
        Slots.Outcome.MANUAL -> toastManual(ctx)
    }
    onDone()
}

/** Shows a widget's preview picture, scaled to fit the box. */
@Composable
private fun PreviewBox(res: Int, w: androidx.compose.ui.unit.Dp, h: androidx.compose.ui.unit.Dp) {
    Box(modifier = Modifier.size(w, h), contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(res),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
private fun WidgetCard(
    title: String,
    body: String,
    preview: Int,
    count: Int,
    onAdd: () -> Unit,
    onCustomize: () -> Unit
) {
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PreviewBox(preview, 96.dp, 96.dp)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (count == 1) "1 placed on your home screen" else "$count placed on your home screen",
            style = MaterialTheme.typography.labelMedium,
            color = glowColor(MaterialTheme.colorScheme.primary)
        )
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlowButton("Add to home screen", onAdd)
            TextButton(
                onClick = onCustomize,
                modifier = Modifier.align(Alignment.CenterVertically),
                colors = ButtonDefaults.textButtonColors(
                    contentColor = glowColor(MaterialTheme.colorScheme.primary)
                )
            ) { Text("Customize") }
        }
    }
}

private fun pin(ctx: Context, cls: Class<*>) {
    if (!WidgetUpdater.requestPin(ctx, cls)) {
        Toast.makeText(
            ctx,
            "Long-press your home screen and open Widgets to add it.",
            Toast.LENGTH_LONG
        ).show()
    }
}

// ---------------------------------------------------------------- Image

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var version by remember { mutableIntStateOf(0) }
    var fill by remember { mutableStateOf(Prefs.fillMode(ctx)) }
    var corner by remember { mutableFloatStateOf(Prefs.cornerDp(ctx).toFloat()) }
    var preview by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(version) {
        preview = withContext(Dispatchers.IO) { ImageStore.load(ctx, null)?.asImageBitmap() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { ImageStore.save(ctx, uri, null) }
                if (ok) {
                    version++
                    WidgetUpdater.updateAll(ctx)
                } else {
                    Toast.makeText(ctx, "Couldn't load that photo", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    val choosePhoto = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    ScreenColumn {
        ScreenTitle("Photo widget", "Default photo for your photo widgets")

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .glass(corner.dp, glowColor(MaterialTheme.colorScheme.primary), 0.9f, spread = 16.dp)
                .clickable { choosePhoto() },
            contentAlignment = Alignment.Center
        ) {
            val bmp = preview
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = "Default photo",
                    contentScale = if (fill) ContentScale.Crop else ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text("Tap to choose a photo", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        GlowButton(
            text = if (preview == null) "Choose photo" else "Change photo",
            onClick = { choosePhoto() },
            modifier = Modifier.fillMaxWidth()
        )

        SectionCard {
            Text("Photo style", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            GlowSegmented(
                options = listOf("Fill", "Fit"),
                selected = if (fill) 0 else 1,
                onSelect = {
                    fill = it == 0
                    Prefs.setFillMode(ctx, fill)
                    WidgetUpdater.updateAll(ctx)
                }
            )
            Spacer(Modifier.height(14.dp))
            Text(
                "Corner radius: ${corner.roundToInt()} dp",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Slider(
                value = corner,
                onValueChange = { corner = it },
                valueRange = 0f..40f,
                colors = SliderDefaults.colors(
                    activeTrackColor = glowColor(MaterialTheme.colorScheme.primary),
                    inactiveTrackColor = Color.White.copy(alpha = 0.12f)
                ),
                thumb = {
                    Box(
                        Modifier
                            .size(22.dp)
                            .neonGlow(glowColor(MaterialTheme.colorScheme.primary), 11.dp, 12.dp, 1.4f, streak = false)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                },
                onValueChangeFinished = {
                    Prefs.setCornerDp(ctx, corner.roundToInt())
                    WidgetUpdater.updateAll(ctx)
                }
            )
        }

        Text(
            "Tip: tap a photo widget on your home screen to give that widget its own photo. " +
                "Widgets without one use this default.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---------------------------------------------------------------- Calendar

@Composable
fun CalendarScreen(mondayFirst: Boolean) {
    val ctx = LocalContext.current
    val locale = Locale.getDefault()
    val today = remember { LocalDate.now() }
    var offset by remember { mutableIntStateOf(0) }
    var granted by remember { mutableStateOf(hasCalendarPermission(ctx)) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        WidgetUpdater.updateAll(ctx)
    }

    val first = today.withDayOfMonth(1).plusMonths(offset.toLong())
    val startDow = if (mondayFirst) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
    val lead = (first.dayOfWeek.value - startDow.value + 7) % 7
    val length = first.lengthOfMonth()

    ScreenColumn {
        ScreenTitle("Calendar widget", "Preview of how your calendar widget looks")

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { offset-- }) {
                    Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "Previous month", tint = Color.White)
                }
                Text(
                    text = first.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = glowColor(MaterialTheme.colorScheme.primary)
                )
                IconButton(onClick = { offset++ }) {
                    Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "Next month", tint = Color.White)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                for (d in 0 until 7) {
                    Text(
                        text = startDow.plus(d.toLong()).getDisplayName(TextStyle.SHORT, locale),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            for (week in 0 until 6) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (d in 0 until 7) {
                        val day = week * 7 + d - lead + 1
                        val inMonth = day in 1..length
                        val isToday = inMonth && first.withDayOfMonth(day) == today
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                                .then(
                                    if (isToday) {
                                        Modifier.neonGlow(
                                            glowColor(MaterialTheme.colorScheme.primary), 100.dp, 12.dp, 1.4f, streak = false
                                        )
                                    } else Modifier
                                )
                                .clip(CircleShape)
                                .background(
                                    if (isToday) {
                                        Brush.verticalGradient(
                                            listOf(
                                                glowColor(MaterialTheme.colorScheme.primary),
                                                MaterialTheme.colorScheme.primary
                                            )
                                        )
                                    } else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (inMonth) {
                                Text(
                                    text = day.toString(),
                                    fontSize = 14.sp,
                                    color = if (isToday) {
                                        Color.White
                                    } else {
                                        Color.White.copy(alpha = 0.88f)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        SectionCard {
            Text("Today's events", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            if (granted) {
                Text(
                    "Calendar access is on. The 4×4 calendar widget lists your events for today.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    "Allow calendar access so the 4×4 widget can list your events for today.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                GlowButton("Allow calendar access", { permission.launch(Manifest.permission.READ_CALENDAR) })
            }
        }
    }
}

// ---------------------------------------------------------------- Settings

private fun Color.lighten(): Color = androidx.compose.ui.graphics.lerp(this, Color.White, 0.18f)

@Composable
fun SettingsScreen(
    accentIndex: Int,
    onAccent: (Int) -> Unit,
    mondayFirst: Boolean,
    onMonday: (Boolean) -> Unit
) {
    val ctx = LocalContext.current

    ScreenColumn {
        ScreenTitle("Settings", "Accent colour is for the app only")

        SectionCard {
            Text("Accent colour", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Prefs.ACCENTS.toList().withIndex().chunked(6).forEachIndexed { rowIdx, rowItems ->
                if (rowIdx > 0) Spacer(Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    rowItems.forEach { (index, argb) ->
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .neonGlow(
                                    Color(argb).lighten(),
                                    22.dp,
                                    spread = 12.dp,
                                    strength = if (index == accentIndex) 1.5f else 0.4f,
                                    streak = false
                                )
                                .clip(CircleShape)
                                .background(
                                    Brush.verticalGradient(listOf(Color(argb).lighten(), Color(argb)))
                                )
                                .clickable { onAccent(index) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (index == accentIndex) {
                                Icon(
                                    Icons.Filled.Check,
                                    contentDescription = Prefs.ACCENT_NAMES[index] + " selected",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Week starts on Monday",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "Used by the calendar widget",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                GlowSwitch(checked = mondayFirst, onCheckedChange = onMonday)
            }
        }

        SectionCard {
            Text("Join us on Telegram", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Updates, new widgets and more from Ranweir\u2019s Inventory.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            GlowButton("Join Telegram", { openTelegram(ctx) }, modifier = Modifier.fillMaxWidth())
        }

        SectionCard {
            GlowButton(
                text = "Refresh all widgets",
                onClick = {
                    WidgetUpdater.updateAll(ctx)
                    Toast.makeText(ctx, "Widgets refreshed", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Widgetly 1.0 · Made by Ranweir",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
