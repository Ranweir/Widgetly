package com.widgetly.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.widgetly.app.CalendarWidgetProvider
import com.widgetly.app.ImageStore
import com.widgetly.app.ImageWidgetProvider
import com.widgetly.app.Prefs
import com.widgetly.app.WidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

// ---------------------------------------------------------------- shared pieces

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = content
    )
}

@Composable
private fun ScreenTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

private fun hasCalendarPermission(ctx: Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) ==
        PackageManager.PERMISSION_GRANTED

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(onGo: (Int) -> Unit) {
    val ctx = LocalContext.current
    val imageCount = remember { WidgetUpdater.count(ctx, ImageWidgetProvider::class.java) }
    val calendarCount = remember { WidgetUpdater.count(ctx, CalendarWidgetProvider::class.java) }

    ScreenColumn {
        ScreenTitle("Widgetly", "Calendar and photo widgets for your home screen")

        WidgetCard(
            title = "Photo widget",
            body = "Show a photo from your gallery. Works in every size from 2×2 to 4×4.",
            count = imageCount,
            onAdd = { pin(ctx, ImageWidgetProvider::class.java) },
            onCustomize = { onGo(1) }
        )
        WidgetCard(
            title = "Calendar widget",
            body = "A month calendar with today highlighted. The 4×4 size also lists today's events.",
            count = calendarCount,
            onAdd = { pin(ctx, CalendarWidgetProvider::class.java) },
            onCustomize = { onGo(2) }
        )

        SectionCard {
            Text(
                "How to add a widget",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Long-press your home screen, open Widgets, find Widgetly and drag a widget out. " +
                    "Then resize it anywhere from 2×2 to 4×4.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun WidgetCard(
    title: String,
    body: String,
    count: Int,
    onAdd: () -> Unit,
    onCustomize: () -> Unit
) {
    SectionCard {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(4.dp))
        Text(
            if (count == 1) "1 placed on your home screen" else "$count placed on your home screen",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAdd) { Text("Add to home screen") }
            TextButton(onClick = onCustomize) { Text("Customize") }
        }
    }
}

private fun pin(ctx: Context, cls: Class<*>) {
    if (!WidgetUpdater.requestPin(ctx, cls)) {
        Toast.makeText(
            ctx,
            "Long-press your home screen and open Widgets to add it.",
            Toast.LENGTH_LONG
        ).show()
    }
}

// ---------------------------------------------------------------- Image

@Composable
fun ImageScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var version by remember { mutableIntStateOf(0) }
    var fill by remember { mutableStateOf(Prefs.fillMode(ctx)) }
    var corner by remember { mutableFloatStateOf(Prefs.cornerDp(ctx).toFloat()) }
    var preview by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(version) {
        preview = withContext(Dispatchers.IO) { ImageStore.load(ctx, null)?.asImageBitmap() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { ImageStore.save(ctx, uri, null) }
                if (ok) {
                    version++
                    WidgetUpdater.updateAll(ctx)
                } else {
                    Toast.makeText(ctx, "Couldn't load that photo", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    val choosePhoto = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    ScreenColumn {
        ScreenTitle("Photo widget", "Default photo for your photo widgets")

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(corner.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable { choosePhoto() },
            contentAlignment = Alignment.Center
        ) {
            val bmp = preview
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = "Default photo",
                    contentScale = if (fill) ContentScale.Crop else ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text("Tap to choose a photo", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Button(onClick = { choosePhoto() }, modifier = Modifier.fillMaxWidth()) {
            Text(if (preview == null) "Choose photo" else "Change photo")
        }

        SectionCard {
            Text("Photo style", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeButton("Fill", fill) {
                    fill = true
                    Prefs.setFillMode(ctx, true)
                    WidgetUpdater.updateAll(ctx)
                }
                ModeButton("Fit", !fill) {
                    fill = false
                    Prefs.setFillMode(ctx, false)
                    WidgetUpdater.updateAll(ctx)
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Corner radius: ${corner.roundToInt()} dp",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Slider(
                value = corner,
                onValueChange = { corner = it },
                valueRange = 0f..40f,
                onValueChangeFinished = {
                    Prefs.setCornerDp(ctx, corner.roundToInt())
                    WidgetUpdater.updateAll(ctx)
                }
            )
        }

        Text(
            "Tip: tap a photo widget on your home screen to give that widget its own photo. " +
                "Widgets without one use this default.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun RowScope.ModeButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, modifier = Modifier.weight(1f)) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f)) { Text(label) }
    }
}

// ---------------------------------------------------------------- Calendar

@Composable
fun CalendarScreen(mondayFirst: Boolean) {
    val ctx = LocalContext.current
    val locale = Locale.getDefault()
    val today = remember { LocalDate.now() }
    var offset by remember { mutableIntStateOf(0) }
    var granted by remember { mutableStateOf(hasCalendarPermission(ctx)) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        WidgetUpdater.updateAll(ctx)
    }

    val first = today.withDayOfMonth(1).plusMonths(offset.toLong())
    val startDow = if (mondayFirst) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
    val lead = (first.dayOfWeek.value - startDow.value + 7) % 7
    val length = first.lengthOfMonth()

    ScreenColumn {
        ScreenTitle("Calendar widget", "Preview of how your calendar widget looks")

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { offset-- }) {
                    Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
                }
                Text(
                    text = first.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                IconButton(onClick = { offset++ }) {
                    Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "Next month")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                for (d in 0 until 7) {
                    Text(
                        text = startDow.plus(d.toLong()).getDisplayName(TextStyle.SHORT, locale),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            for (week in 0 until 6) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (d in 0 until 7) {
                        val day = week * 7 + d - lead + 1
                        val inMonth = day in 1..length
                        val isToday = inMonth && first.withDayOfMonth(day) == today
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                                .clip(CircleShape)
                                .background(if (isToday) MaterialTheme.colorScheme.primary else Color.Transparent),
                            contentAlignment = Alignment.Center
                        ) {
                            if (inMonth) {
                                Text(
                                    text = day.toString(),
                                    fontSize = 14.sp,
                                    color = if (isToday) {
                                        MaterialTheme.colorScheme.onPrimary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        SectionCard {
            Text("Today's events", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            if (granted) {
                Text(
                    "Calendar access is on. The 4×4 calendar widget lists your events for today.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    "Allow calendar access so the 4×4 widget can list your events for today.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { permission.launch(Manifest.permission.READ_CALENDAR) }) {
                    Text("Allow calendar access")
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Settings

@Composable
fun SettingsScreen(
    accentIndex: Int,
    onAccent: (Int) -> Unit,
    mondayFirst: Boolean,
    onMonday: (Boolean) -> Unit
) {
    val ctx = LocalContext.current

    ScreenColumn {
        ScreenTitle("Settings", "Applies to the app and to every widget")

        SectionCard {
            Text("Accent colour", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Prefs.ACCENTS.toList().withIndex().chunked(6).forEachIndexed { rowIdx, rowItems ->
                if (rowIdx > 0) Spacer(Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    rowItems.forEach { (index, argb) ->
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(argb))
                                .clickable { onAccent(index) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (index == accentIndex) {
                                Icon(
                                    Icons.Filled.Check,
                                    contentDescription = Prefs.ACCENT_NAMES[index] + " selected",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Week starts on Monday",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "Used by the calendar widget",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = mondayFirst, onCheckedChange = onMonday)
            }
        }

        SectionCard {
            Button(
                onClick = {
                    WidgetUpdater.updateAll(ctx)
                    Toast.makeText(ctx, "Widgets refreshed", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Refresh all widgets")
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Widgetly 1.0",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
