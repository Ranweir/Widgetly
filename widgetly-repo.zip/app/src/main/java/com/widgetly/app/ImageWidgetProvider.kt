package com.widgetly.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.RemoteViews

/**
 * Photo widget. Works at every size from 2x2 to 4x4 (and anything in between):
 * the photo is drawn at the widget's own pixel size, with rounded corners,
 * either filling the widget (crop) or fitting inside it.
 * Tapping the widget lets you pick a different photo for that widget.
 */
object ImageWidgetProvider {
        fun update(context: Context, mgr: AppWidgetManager, id: Int) {
            val rv = RemoteViews(context.packageName, R.layout.widget_image)
            val px = WidgetSize.pixelSize(context, mgr, id)
            val bitmap = render(context, id, px)

            if (bitmap != null) {
                rv.setImageViewBitmap(R.id.img, bitmap)
                rv.setViewVisibility(R.id.img, View.VISIBLE)
                rv.setViewVisibility(R.id.img_hint, View.GONE)
            } else {
                rv.setViewVisibility(R.id.img, View.GONE)
                rv.setViewVisibility(R.id.img_hint, View.VISIBLE)
            }

            val intent = Intent(context, ImageConfigActivity::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pending = PendingIntent.getActivity(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.img_root, pending)

            mgr.updateAppWidget(id, rv)
        }

        private fun render(context: Context, id: Int, px: WidgetSize.PxSize): Bitmap? {
            val src = ImageStore.loadForWidget(context, id) ?: return null
            val w = px.w
            val h = px.h
            val sw = src.width.toFloat()
            val sh = src.height.toFloat()

            val dst: RectF
            val srcRect: RectF
            if (Prefs.fillMode(context)) {
                dst = RectF(0f, 0f, w.toFloat(), h.toFloat())
                val s = maxOf(w / sw, h / sh)
                val visibleW = w / s
                val visibleH = h / s
                srcRect = RectF(
                    (sw - visibleW) / 2f, (sh - visibleH) / 2f,
                    (sw + visibleW) / 2f, (sh + visibleH) / 2f
                )
            } else {
                val s = minOf(w / sw, h / sh)
                val dw = sw * s
                val dh = sh * s
                dst = RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
                srcRect = RectF(0f, 0f, sw, sh)
            }

            val shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val matrix = Matrix()
            matrix.setRectToRect(srcRect, dst, Matrix.ScaleToFit.FILL)
            shader.setLocalMatrix(matrix)

            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            paint.shader = shader

            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val radius = Prefs.cornerDp(context) * context.resources.displayMetrics.density * px.scale
            Canvas(out).drawRoundRect(dst, radius, radius, paint)
            src.recycle()
            return out
        }
}
