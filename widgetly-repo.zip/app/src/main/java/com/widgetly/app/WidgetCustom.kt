package com.widgetly.app

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import androidx.core.graphics.ColorUtils

/**
 * Per-widget look chosen in the widget settings. Everything is optional: a value that was never
 * set (null / -1) leaves the style's own colours alone.
 *
 * If only a background colour is set, text and highlight switch to a readable colour for it.
 */
class WidgetCustom(
    val bg: Int?,
    /** 0..100, or -1 when not changed. */
    val alpha: Int,
    val text: Int?,
    val today: Int?,
    val scale: Float,
    val events: Boolean,
    val monday: Boolean?
) {
    private val auto: Int? get() = text ?: bg?.let { contrast(it) }
    private val hiOverride: Int? get() = today ?: auto

    fun text(def: Int): Int = auto ?: def
    fun dim(def: Int): Int = auto?.let { withAlpha(it, 0xB3) } ?: def
    fun faint(def: Int): Int = auto?.let { withAlpha(it, 0x99) } ?: def
    fun hi(def: Int): Int = hiOverride ?: def
    fun halo(def: Int): Int = hiOverride?.let { withAlpha(it, 0x55) } ?: def
    fun onHi(def: Int): Int = hiOverride?.let { contrast(it) } ?: def
    fun size(base: Float): Float = base * scale

    fun mondayFirst(c: Context): Boolean = monday ?: Prefs.mondayFirst(c)

    /** Applies background colour and opacity to the widget's bg_fill image. */
    fun applyBg(rv: RemoteViews) {
        if (bg != null) {
            rv.setViewVisibility(R.id.bg_fill, View.VISIBLE)
            rv.setViewVisibility(R.id.bg_glow, View.GONE)
            rv.setInt(R.id.bg_fill, "setColorFilter", bg or 0xFF000000.toInt())
        }
        if (alpha in 0..99) {
            rv.setInt(R.id.bg_fill, "setImageAlpha", alpha * 255 / 100)
        }
    }

    companion object {
        val DARK = 0xFF14141F.toInt()

        fun contrast(c: Int): Int = if (ColorUtils.calculateLuminance(c) > 0.55) DARK else Color.WHITE
        fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)
    }
}
