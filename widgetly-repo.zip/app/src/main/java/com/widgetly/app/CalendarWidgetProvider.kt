package com.widgetly.app

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Date
import java.util.Locale

/**
 * Month calendar widget. Layout depends on the widget size:
 *  - 2x2: compact month grid
 *  - 3x3: larger month grid
 *  - 4x4: month grid + today's events (needs calendar permission)
 */
class CalendarWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { update(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle?
    ) {
        update(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { Prefs.clearCalendar(context, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        when (intent.action) {
            ACTION_PREV, ACTION_NEXT, ACTION_RESET -> {
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                    val cur = Prefs.calOffset(context, id)
                    val next = when (intent.action) {
                        ACTION_PREV -> cur - 1
                        ACTION_NEXT -> cur + 1
                        else -> 0
                    }
                    Prefs.setCalOffset(context, id, next)
                    update(context, AppWidgetManager.getInstance(context), id)
                }
            }
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> updateAll(context)
        }
    }

    companion object {
        const val ACTION_PREV = "com.widgetly.app.CAL_PREV"
        const val ACTION_NEXT = "com.widgetly.app.CAL_NEXT"
        const val ACTION_RESET = "com.widgetly.app.CAL_RESET"

        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            mgr.getAppWidgetIds(ComponentName(context, CalendarWidgetProvider::class.java))
                .forEach { update(context, mgr, it) }
        }

        fun update(context: Context, mgr: AppWidgetManager, id: Int) =
            CalendarRenderer.render(context, mgr, id)
    }
}
