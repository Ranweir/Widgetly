package com.widgetly.app

import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Not a widget itself (it never shows in the widget picker). It receives the month ‹ › / title taps
 * from calendar widgets and the date / time-zone changes that need a redraw.
 */
class CalendarWidgetProvider : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        when (intent.action) {
            ACTION_PREV, ACTION_NEXT, ACTION_RESET -> {
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                    val cur = Prefs.calOffset(context, id)
                    val next = when (intent.action) {
                        ACTION_PREV -> cur - 1
                        ACTION_NEXT -> cur + 1
                        else -> 0
                    }
                    Prefs.setCalOffset(context, id, next)
                    CalendarRenderer.render(context, AppWidgetManager.getInstance(context), id)
                }
            }
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> SlotWidgetProvider.updateAll(context)
        }
    }

    companion object {
        const val ACTION_PREV = "com.widgetly.app.CAL_PREV"
        const val ACTION_NEXT = "com.widgetly.app.CAL_NEXT"
        const val ACTION_RESET = "com.widgetly.app.CAL_RESET"
    }
}
