package com.widgetly.app

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Date
import java.util.Locale

/**
 * Month calendar widget. Layout depends on the widget size:
 *  - 2x2: compact month grid
 *  - 3x3: larger month grid
 *  - 4x4: month grid + today's events (needs calendar permission)
 */
class CalendarWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { update(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle?
    ) {
        update(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { Prefs.clearCalendar(context, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        when (intent.action) {
            ACTION_PREV, ACTION_NEXT, ACTION_RESET -> {
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                    val cur = Prefs.calOffset(context, id)
                    val next = when (intent.action) {
                        ACTION_PREV -> cur - 1
                        ACTION_NEXT -> cur + 1
                        else -> 0
                    }
                    Prefs.setCalOffset(context, id, next)
                    update(context, AppWidgetManager.getInstance(context), id)
                }
            }
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> updateAll(context)
        }
    }

    companion object {
        const val ACTION_PREV = "com.widgetly.app.CAL_PREV"
        const val ACTION_NEXT = "com.widgetly.app.CAL_NEXT"
        const val ACTION_RESET = "com.widgetly.app.CAL_RESET"

        private val CELLS = intArrayOf(
            R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5, R.id.c6
        )
        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            mgr.getAppWidgetIds(ComponentName(context, CalendarWidgetProvider::class.java))
                .forEach { update(context, mgr, it) }
        }

        fun update(context: Context, mgr: AppWidgetManager, id: Int) = CalendarRenderer.render(context, mgr, id)

        fun renderClassic(context: Context, mgr: AppWidgetManager, id: Int) {
            val sizeClass = WidgetSize.sizeClass(mgr, id)
            val layoutRes = when (sizeClass) {
                2 -> R.layout.widget_calendar_small
                3 -> R.layout.widget_calendar_medium
                else -> R.layout.widget_calendar_large
            }
            val rowRes = when (sizeClass) {
                2 -> R.layout.cal_row_small
                3 -> R.layout.cal_row_medium
                else -> R.layout.cal_row_large
            }
            val weekdayRes = when (sizeClass) {
                2 -> R.layout.cal_wd_small
                3 -> R.layout.cal_wd_medium
                else -> R.layout.cal_wd_large
            }

            val rv = RemoteViews(context.packageName, layoutRes)
            val locale = Locale.getDefault()
            val today = LocalDate.now()
            val first = today.withDayOfMonth(1).plusMonths(Prefs.calOffset(context, id).toLong())

            val pattern = if (sizeClass == 2) "MMM yyyy" else "MMMM yyyy"
            rv.setTextViewText(R.id.cal_title, first.format(DateTimeFormatter.ofPattern(pattern, locale)))
            rv.setTextColor(R.id.cal_title, ContextCompat.getColor(context, R.color.widget_text))

            val startDow = if (Prefs.mondayFirst(context)) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
            val lead = (first.dayOfWeek.value - startDow.value + 7) % 7
            val length = first.lengthOfMonth()

            rv.removeAllViews(R.id.cal_grid)

            val weekdays = RemoteViews(context.packageName, weekdayRes)
            for (d in 0 until 7) {
                weekdays.setTextViewText(
                    CELLS[d],
                    startDow.plus(d.toLong()).getDisplayName(TextStyle.NARROW, locale)
                )
            }
            rv.addView(R.id.cal_grid, weekdays)

            for (week in 0 until 6) {
                val row = RemoteViews(context.packageName, rowRes)
                for (d in 0 until 7) {
                    val day = week * 7 + d - lead + 1
                    val cell = CELLS[d]
                    if (day in 1..length) {
                        row.setTextViewText(cell, day.toString())
                        if (first.withDayOfMonth(day) == today) {
                            row.setInt(cell, "setBackgroundResource", R.drawable.bg_today)
                            row.setTextColor(cell, ContextCompat.getColor(context, R.color.widget_today_text))
                        }
                    } else {
                        row.setTextViewText(cell, "")
                    }
                }
                rv.addView(R.id.cal_grid, row)
            }

            rv.setOnClickPendingIntent(R.id.cal_prev, broadcast(context, id, ACTION_PREV, 1))
            rv.setOnClickPendingIntent(R.id.cal_next, broadcast(context, id, ACTION_NEXT, 2))
            rv.setOnClickPendingIntent(R.id.cal_title, broadcast(context, id, ACTION_RESET, 3))
            rv.setOnClickPendingIntent(R.id.cal_grid, openCalendar(context, id))

            if (sizeClass >= 4) bindEvents(context, rv, id)

            mgr.updateAppWidget(id, rv)
        }

        private fun bindEvents(context: Context, rv: RemoteViews, id: Int) {
            val granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_CALENDAR
            ) == PackageManager.PERMISSION_GRANTED
            val events = if (granted) todaysEvents(context) else emptyList()

            val evIds = intArrayOf(R.id.ev0, R.id.ev1, R.id.ev2)
            evIds.forEachIndexed { i, viewId ->
                if (i < events.size) {
                    rv.setTextViewText(viewId, events[i])
                    rv.setViewVisibility(viewId, View.VISIBLE)
                } else {
                    rv.setViewVisibility(viewId, View.GONE)
                }
            }

            val hint = when {
                !granted -> context.getString(R.string.hint_allow_calendar)
                events.isEmpty() -> context.getString(R.string.hint_no_events)
                else -> null
            }
            if (hint != null) {
                rv.setTextViewText(R.id.ev_hint, hint)
                rv.setViewVisibility(R.id.ev_hint, View.VISIBLE)
            } else {
                rv.setViewVisibility(R.id.ev_hint, View.GONE)
            }
            rv.setOnClickPendingIntent(R.id.events_box, openCalendar(context, id))
        }

        private fun todaysEvents(context: Context): List<String> {
            val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val end = start + 24L * 60 * 60 * 1000
            val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(builder, start)
            ContentUris.appendId(builder, end)

            val out = ArrayList<String>()
            try {
                context.contentResolver.query(
                    builder.build(),
                    arrayOf(
                        CalendarContract.Instances.TITLE,
                        CalendarContract.Instances.BEGIN,
                        CalendarContract.Instances.ALL_DAY
                    ),
                    null,
                    null,
                    "${CalendarContract.Instances.BEGIN} ASC"
                )?.use { c ->
                    val timeFormat = DateFormat.getTimeFormat(context)
                    while (c.moveToNext() && out.size < 3) {
                        val title = c.getString(0)?.takeIf { it.isNotBlank() }
                            ?: context.getString(R.string.event_untitled)
                        val allDay = c.getInt(2) == 1
                        out.add(if (allDay) title else timeFormat.format(Date(c.getLong(1))) + "  " + title)
                    }
                }
            } catch (e: Exception) {
                // No permission or provider problem: show no events.
            }
            return out
        }

        private fun broadcast(context: Context, id: Int, action: String, n: Int): PendingIntent {
            val intent = Intent(context, CalendarWidgetProvider::class.java)
                .setAction(action)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            return PendingIntent.getBroadcast(
                context, id * 10 + n, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun openCalendar(context: Context, id: Int): PendingIntent {
            val intent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("content://com.android.calendar/time/${System.currentTimeMillis()}")
            )
            return PendingIntent.getActivity(
                context, id * 10 + 4, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
