package com.widgetly.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private const val TELEGRAM_URL = "https://t.me/ranweirsinventory"

fun openTelegram(ctx: android.content.Context) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: ActivityNotFoundException) {
    }
}

/** Glowing crystal icon from the kit's modal window. */
private fun DrawScope.drawGem() {
    val w = size.width
    val h = size.height
    val ice = Color(0xFF8FD0FF)
    // soft light halo
    for (i in 6 downTo 1) {
        val t = i / 6f
        drawCircle(
            ice.a(0.05f + 0.10f * (1f - t) * (1f - t)),
            radius = w * 0.34f + w * 0.30f * t,
            center = center
        )
    }
    val top = Offset(w / 2f, h * 0.06f)
    val right = Offset(w * 0.94f, h * 0.50f)
    val bottom = Offset(w / 2f, h * 0.94f)
    val left = Offset(w * 0.06f, h * 0.50f)
    val body = Path().apply {
        moveTo(top.x, top.y)
        lineTo(right.x, right.y)
        lineTo(bottom.x, bottom.y)
        lineTo(left.x, left.y)
        close()
    }
    drawPath(body, Brush.linearGradient(listOf(Color(0xFFD9F0FF), Color(0xFF4FA8F0)), top, bottom))
    // facets
    val facet = Path().apply {
        moveTo(left.x, left.y); lineTo(top.x, top.y); lineTo(w * 0.5f, h * 0.5f); close()
    }
    drawPath(facet, Color.White.a(0.35f))
    val facet2 = Path().apply {
        moveTo(right.x, right.y); lineTo(bottom.x, bottom.y); lineTo(w * 0.5f, h * 0.5f); close()
    }
    drawPath(facet2, Color(0xFF1E6FC0).a(0.35f))
    drawPath(body, Color.White.a(0.7f), style = Stroke(1.dp.toPx()))
}

/** Shown every time the app is opened. Modelled on the kit's modal window. */
@Composable
fun TelegramDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val glow = glowColor(MaterialTheme.colorScheme.primary)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        // padding leaves room for the glow and the stacked layers behind the panel
        Column(modifier = Modifier.fillMaxWidth().padding(PaddingValues(start = 22.dp, top = 24.dp, end = 30.dp, bottom = 32.dp))) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glass(18.dp, glow, strength = 1.1f, spread = 16.dp, stack = true)
                    .padding(horizontal = 22.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Canvas(Modifier.size(48.dp)) { drawGem() }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Join us on Telegram",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Updates, new widgets and more from Ranweir\u2019s Inventory.",
                    color = Color.White.a(0.55f),
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GlowButton(
                        text = "Close",
                        onClick = onClose,
                        modifier = Modifier.weight(1f),
                        primary = false,
                        height = 38.dp
                    )
                    GlowButton(
                        text = "Telegram",
                        onClick = {
                            openTelegram(ctx)
                            onClose()
                        },
                        modifier = Modifier.weight(1f),
                        height = 38.dp
                    )
                }
            }
        }
    }
}
