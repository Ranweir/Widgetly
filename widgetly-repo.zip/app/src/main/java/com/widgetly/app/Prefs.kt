package com.widgetly.app

import android.content.Context

/** Small SharedPreferences wrapper shared by the app and the widget providers. */
object Prefs {
    private const val NAME = "widgetly_prefs"

    // Keep the first five in this order (saved choices use the index)
    val ACCENTS = intArrayOf(
        0xFF4F46E5.toInt(), // Indigo
        0xFF7C3AED.toInt(), // Violet
        0xFF2563EB.toInt(), // Blue
        0xFFE11D48.toInt(), // Rose
        0xFFEA580C.toInt(), // Orange
        0xFF0D9488.toInt(), // Teal
        0xFF059669.toInt(), // Emerald
        0xFF16A34A.toInt(), // Green
        0xFF0891B2.toInt(), // Cyan
        0xFFDB2777.toInt(), // Pink
        0xFFDC2626.toInt(), // Red
        0xFF475569.toInt(), // Slate
        0xFFFF2D3A.toInt(), // Neon red
        0xFFFF6B6B.toInt(), // Coral
        0xFFF59E0B.toInt(), // Amber
        0xFFEAB308.toInt(), // Yellow
        0xFF84CC16.toInt(), // Lime
        0xFF2DD4BF.toInt(), // Mint
        0xFF0EA5E9.toInt(), // Sky
        0xFF1D4ED8.toInt(), // Royal blue
        0xFFC026D3.toInt(), // Fuchsia
        0xFFA78BFA.toInt(), // Lavender
        0xFF9F1239.toInt(), // Maroon
        0xFFCBD5E1.toInt()  // Silver
    )
    val ACCENT_NAMES = listOf(
        "Indigo", "Violet", "Blue", "Rose", "Orange", "Teal",
        "Emerald", "Green", "Cyan", "Pink", "Red", "Slate",
        "Neon red", "Coral", "Amber", "Yellow", "Lime", "Mint",
        "Sky", "Royal blue", "Fuchsia", "Lavender", "Maroon", "Silver"
    )

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun accentIndex(c: Context): Int =
        sp(c).getInt("accent", 12).coerceIn(0, ACCENTS.size - 1)

    fun setAccentIndex(c: Context, i: Int) {
        sp(c).edit().putInt("accent", i).apply()
    }

    fun mondayFirst(c: Context): Boolean = sp(c).getBoolean("monday_first", false)

    fun setMondayFirst(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("monday_first", v).apply()
    }

    /** true = fill (crop to fit the widget), false = fit (whole photo visible). */
    fun fillMode(c: Context): Boolean = sp(c).getBoolean("img_fill", true)

    fun setFillMode(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("img_fill", v).apply()
    }

    fun cornerDp(c: Context): Int = sp(c).getInt("img_corner", 20)

    fun setCornerDp(c: Context, v: Int) {
        sp(c).edit().putInt("img_corner", v).apply()
    }

    /** Months shown away from the current month, per calendar widget. */
    fun calOffset(c: Context, id: Int): Int = sp(c).getInt("cal_offset_$id", 0)

    fun setCalOffset(c: Context, id: Int, v: Int) {
        sp(c).edit().putInt("cal_offset_$id", v).apply()
    }

    fun clearCalendar(c: Context, id: Int) {
        sp(c).edit().remove("cal_offset_$id").apply()
    }
}
