package com.widgetly.app

import android.content.Context

/** Small SharedPreferences wrapper shared by the app and the widget providers. */
object Prefs {
    private const val NAME = "widgetly_prefs"

    // Keep the first five in this order (saved choices use the index)
    val ACCENTS = intArrayOf(
        0xFF4F46E5.toInt(), // Indigo
        0xFF7C3AED.toInt(), // Violet
        0xFF2563EB.toInt(), // Blue
        0xFFE11D48.toInt(), // Rose
        0xFFEA580C.toInt(), // Orange
        0xFF0D9488.toInt(), // Teal
        0xFF059669.toInt(), // Emerald
        0xFF16A34A.toInt(), // Green
        0xFF0891B2.toInt(), // Cyan
        0xFFDB2777.toInt(), // Pink
        0xFFDC2626.toInt(), // Red
        0xFF475569.toInt(), // Slate
        0xFFFF2D3A.toInt(), // Neon red
        0xFFFF6B6B.toInt(), // Coral
        0xFFF59E0B.toInt(), // Amber
        0xFFEAB308.toInt(), // Yellow
        0xFF84CC16.toInt(), // Lime
        0xFF2DD4BF.toInt(), // Mint
        0xFF0EA5E9.toInt(), // Sky
        0xFF1D4ED8.toInt(), // Royal blue
        0xFFC026D3.toInt(), // Fuchsia
        0xFFA78BFA.toInt(), // Lavender
        0xFF9F1239.toInt(), // Maroon
        0xFFCBD5E1.toInt()  // Silver
    )
    val ACCENT_NAMES = listOf(
        "Indigo", "Violet", "Blue", "Rose", "Orange", "Teal",
        "Emerald", "Green", "Cyan", "Pink", "Red", "Slate",
        "Neon red", "Coral", "Amber", "Yellow", "Lime", "Mint",
        "Sky", "Royal blue", "Fuchsia", "Lavender", "Maroon", "Silver"
    )

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun accentIndex(c: Context): Int =
        sp(c).getInt("accent", 12).coerceIn(0, ACCENTS.size - 1)

    fun setAccentIndex(c: Context, i: Int) {
        sp(c).edit().putInt("accent", i).apply()
    }

    fun mondayFirst(c: Context): Boolean = sp(c).getBoolean("monday_first", false)

    fun setMondayFirst(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("monday_first", v).apply()
    }

    /** true = fill (crop to fit the widget), false = fit (whole photo visible). */
    fun fillMode(c: Context): Boolean = sp(c).getBoolean("img_fill", true)

    fun setFillMode(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("img_fill", v).apply()
    }

    fun cornerDp(c: Context): Int = sp(c).getInt("img_corner", 20)

    fun setCornerDp(c: Context, v: Int) {
        sp(c).edit().putInt("img_corner", v).apply()
    }

    /** Months shown away from the current month, per calendar widget. */
    fun calOffset(c: Context, id: Int): Int = sp(c).getInt("cal_offset_$id", 0)

    fun setCalOffset(c: Context, id: Int, v: Int) {
        sp(c).edit().putInt("cal_offset_$id", v).apply()
    }

    /** Chosen design for one calendar widget, or -1 if it was never changed. */
    fun calStyle(c: Context, id: Int): Int = sp(c).getInt("cal_style_$id", -1)

    fun setCalStyle(c: Context, id: Int, v: Int) {
        sp(c).edit().putInt("cal_style_$id", v).apply()
    }

    /** Per-widget look: colours, opacity, text size, events, week start. */
    fun custom(c: Context, id: Int): WidgetCustom {
        val p = sp(c)
        return WidgetCustom(
            bg = if (p.contains("cu_bg_$id")) p.getInt("cu_bg_$id", 0) else null,
            alpha = p.getInt("cu_alpha_$id", -1),
            text = if (p.contains("cu_text_$id")) p.getInt("cu_text_$id", 0) else null,
            today = if (p.contains("cu_today_$id")) p.getInt("cu_today_$id", 0) else null,
            scale = when (p.getInt("cu_size_$id", 1)) { 0 -> 0.85f; 2 -> 1.2f; else -> 1f },
            events = p.getBoolean("cu_events_$id", true),
            monday = when (p.getInt("cu_monday_$id", -1)) { 0 -> false; 1 -> true; else -> null }
        )
    }

    fun saveCustom(
        c: Context, id: Int, bg: Int?, alpha: Int, text: Int?, today: Int?,
        sizeIdx: Int, events: Boolean, monday: Int
    ) {
        val e = sp(c).edit()
        fun opt(key: String, v: Int?) { if (v == null) e.remove(key) else e.putInt(key, v) }
        opt("cu_bg_$id", bg)
        opt("cu_text_$id", text)
        opt("cu_today_$id", today)
        e.putInt("cu_alpha_$id", alpha)
        e.putInt("cu_size_$id", sizeIdx)
        e.putBoolean("cu_events_$id", events)
        e.putInt("cu_monday_$id", monday)
        e.apply()
    }

    /** Raw saved values for the settings screen. */
    fun customRaw(c: Context, id: Int): IntArray {
        val p = sp(c)
        return intArrayOf(
            p.getInt("cu_alpha_$id", -1), p.getInt("cu_size_$id", 1),
            if (p.getBoolean("cu_events_$id", true)) 1 else 0, p.getInt("cu_monday_$id", -1)
        )
    }

    /** What an app widget currently shows: "cal", "photo", or null while it is still empty. */
    fun slotType(c: Context, id: Int): String? = sp(c).getString("slot_type_$id", null)

    fun setSlotType(c: Context, id: Int, v: String?) {
        val e = sp(c).edit()
        if (v == null) e.remove("slot_type_$id") else e.putString("slot_type_$id", v)
        e.apply()
    }

    /** A style asked for in the app while no empty widget existed; used by the next widget added. */
    fun setPending(c: Context, token: Int) {
        sp(c).edit().putInt("slot_pending", token).putLong("slot_pending_at", System.currentTimeMillis()).apply()
    }

    fun clearPending(c: Context) {
        sp(c).edit().remove("slot_pending").remove("slot_pending_at").apply()
    }

    /** Returns the pending style (if it is fresh) and forgets it. */
    fun takePending(c: Context): Int? {
        val p = sp(c)
        if (!p.contains("slot_pending")) return null
        val token = p.getInt("slot_pending", 0)
        val fresh = System.currentTimeMillis() - p.getLong("slot_pending_at", 0L) < 2 * 60 * 1000L
        clearPending(c)
        return if (fresh) token else null
    }

    fun clearCalendar(c: Context, id: Int) {
        val e = sp(c).edit().remove("cal_offset_$id").remove("cal_style_$id")
        for (k in listOf("cu_bg_", "cu_alpha_", "cu_text_", "cu_today_", "cu_size_", "cu_events_", "cu_monday_")) {
            e.remove(k + id)
        }
        e.apply()
    }
}
