package com.widgetly.app

import android.content.Context

/** Small SharedPreferences wrapper shared by the app and the widget providers. */
object Prefs {
    private const val NAME = "widgetly_prefs"

    val ACCENTS = intArrayOf(
        0xFF4F46E5.toInt(), // Indigo
        0xFF7C3AED.toInt(), // Violet
        0xFF2563EB.toInt(), // Blue
        0xFFE11D48.toInt(), // Rose
        0xFFEA580C.toInt()  // Orange
    )
    val ACCENT_NAMES = listOf("Indigo", "Violet", "Blue", "Rose", "Orange")

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun accentIndex(c: Context): Int =
        sp(c).getInt("accent", 0).coerceIn(0, ACCENTS.size - 1)

    fun setAccentIndex(c: Context, i: Int) {
        sp(c).edit().putInt("accent", i).apply()
    }

    fun mondayFirst(c: Context): Boolean = sp(c).getBoolean("monday_first", false)

    fun setMondayFirst(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("monday_first", v).apply()
    }

    /** true = fill (crop to fit the widget), false = fit (whole photo visible). */
    fun fillMode(c: Context): Boolean = sp(c).getBoolean("img_fill", true)

    fun setFillMode(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("img_fill", v).apply()
    }

    fun cornerDp(c: Context): Int = sp(c).getInt("img_corner", 20)

    fun setCornerDp(c: Context, v: Int) {
        sp(c).edit().putInt("img_corner", v).apply()
    }

    /** Months shown away from the current month, per calendar widget. */
    fun calOffset(c: Context, id: Int): Int = sp(c).getInt("cal_offset_$id", 0)

    fun setCalOffset(c: Context, id: Int, v: Int) {
        sp(c).edit().putInt("cal_offset_$id", v).apply()
    }

    fun clearCalendar(c: Context, id: Int) {
        sp(c).edit().remove("cal_offset_$id").apply()
    }
}
