package com.widgetly.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** The glass + glow look is dark-only, so the app always uses the dark scheme. */
@Composable
fun WidgetlyTheme(accent: Color, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = Color.White,
        secondary = glowColor(accent),
        background = Color(0xFF08090D),
        onBackground = Color(0xFFF4F4F8),
        surface = Color(0xFF12131A),
        onSurface = Color(0xFFF4F4F8),
        surfaceVariant = Color(0xFF1C1D27),
        onSurfaceVariant = Color(0xFFA3A6B8),
        outlineVariant = Color(0x1FFFFFFF)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
