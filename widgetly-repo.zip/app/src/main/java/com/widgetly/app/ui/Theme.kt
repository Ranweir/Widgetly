package com.widgetly.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun WidgetlyTheme(accent: Color, content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color.White,
            background = Color(0xFF0F1020),
            onBackground = Color(0xFFECECF6),
            surface = Color(0xFF1A1C30),
            onSurface = Color(0xFFECECF6),
            surfaceVariant = Color(0xFF24263D),
            onSurfaceVariant = Color(0xFFA9ABC6)
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            background = Color(0xFFF4F5FB),
            onBackground = Color(0xFF1B1B2F),
            surface = Color.White,
            onSurface = Color(0xFF1B1B2F),
            surfaceVariant = Color(0xFFE9EAF5),
            onSurfaceVariant = Color(0xFF6B6D86)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
