package com.widgetly.app

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Date
import java.util.Locale

/** Every extra calendar widget design, listed so the app can offer them on the Home tab. */
class StyleInfo(val name: String, val desc: String, val cls: Class<*>)

object CalendarStyles {
    val LIST = listOf(
        StyleInfo("Glow Month", "Dark glass month, glowing edge and glowing today.", GlowMonthProvider::class.java),
        StyleInfo("Bold Month", "Solid accent colour with a white today.", BoldMonthProvider::class.java),
        StyleInfo("Minimal Month", "Transparent, sits right on your wallpaper.", MinimalMonthProvider::class.java),
        StyleInfo("Date Card", "Big date, plus today's events when tall.", DateCardProvider::class.java),
        StyleInfo("Week Strip", "This week in a glowing strip (4×2).", WeekStripProvider::class.java),
        StyleInfo("Agenda", "Your next events this week (4×3).", AgendaProvider::class.java)
    )

    fun updateAll(c: Context) {
        listOf<BaseProvider>(
            GlowMonthProvider(), BoldMonthProvider(), MinimalMonthProvider(),
            DateCardProvider(), WeekStripProvider(), AgendaProvider()
        ).forEach { it.updateOwn(c) }
    }
}

internal fun accentOf(c: Context): Int = Prefs.ACCENTS[Prefs.accentIndex(c)]
internal fun glowOf(argb: Int): Int = ColorUtils.blendARGB(argb, Color.WHITE, 0.25f)

/** Calendar events helper shared by the new widgets. */
object Events {
    class Item(val date: LocalDate, val time: String?, val title: String) {
        fun line(): String = if (time == null) title else "$time  $title"
    }

    fun granted(c: Context) = ContextCompat.checkSelfPermission(
        c, Manifest.permission.READ_CALENDAR
    ) == PackageManager.PERMISSION_GRANTED

    /** Events from today for [days] days, skipping ones that already finished. */
    fun upcoming(c: Context, days: Int, limit: Int): List<Item> {
        if (!granted(c)) return emptyList()
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now()
        val start = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = today.plusDays(days.toLong()).atStartOfDay(zone).toInstant().toEpochMilli()
        val now = System.currentTimeMillis()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, start)
        ContentUris.appendId(b, end)
        val out = ArrayList<Item>()
        try {
            c.contentResolver.query(
                b.build(),
                arrayOf(
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.END,
                    CalendarContract.Instances.ALL_DAY
                ),
                null, null, "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { cur ->
                val tf = DateFormat.getTimeFormat(c)
                while (cur.moveToNext() && out.size < limit) {
                    val title = cur.getString(0)?.takeIf { it.isNotBlank() }
                        ?: c.getString(R.string.event_untitled)
                    val begin = cur.getLong(1)
                    val endMs = cur.getLong(2)
                    val allDay = cur.getInt(3) == 1
                    if (!allDay && endMs < now) continue
                    val date = Instant.ofEpochMilli(begin)
                        .atZone(if (allDay) ZoneOffset.UTC else zone).toLocalDate()
                    out.add(Item(if (date.isBefore(today)) today else date, if (allDay) null else tf.format(Date(begin)), title))
                }
            }
        } catch (e: Exception) {
            // No permission or provider problem: show nothing.
        }
        return out
    }

    /** Fills up to ids.size one-line views and a hint line. */
    fun bindLines(c: Context, rv: RemoteViews, items: List<Item>, ids: IntArray, hintId: Int) {
        ids.forEachIndexed { i, id ->
            if (i < items.size) {
                rv.setTextViewText(id, items[i].line())
                rv.setViewVisibility(id, View.VISIBLE)
            } else {
                rv.setViewVisibility(id, View.GONE)
            }
        }
        val hint = when {
            !granted(c) -> c.getString(R.string.hint_allow_calendar)
            items.isEmpty() -> c.getString(R.string.hint_no_events)
            else -> null
        }
        if (hint != null) {
            rv.setTextViewText(hintId, hint)
            rv.setViewVisibility(hintId, View.VISIBLE)
        } else {
            rv.setViewVisibility(hintId, View.GONE)
        }
    }
}

abstract class BaseProvider : AppWidgetProvider() {

    abstract fun render(context: Context, mgr: AppWidgetManager, id: Int)

    fun updateOwn(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        mgr.getAppWidgetIds(ComponentName(context, javaClass)).forEach { render(context, mgr, it) }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { render(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?
    ) {
        render(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { Prefs.clearCalendar(context, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        when (intent.action) {
            CalendarWidgetProvider.ACTION_PREV,
            CalendarWidgetProvider.ACTION_NEXT,
            CalendarWidgetProvider.ACTION_RESET -> {
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                    val cur = Prefs.calOffset(context, id)
                    val next = when (intent.action) {
                        CalendarWidgetProvider.ACTION_PREV -> cur - 1
                        CalendarWidgetProvider.ACTION_NEXT -> cur + 1
                        else -> 0
                    }
                    Prefs.setCalOffset(context, id, next)
                    render(context, AppWidgetManager.getInstance(context), id)
                }
            }
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> WidgetUpdater.updateAll(context)
        }
    }

    protected fun broadcast(context: Context, id: Int, action: String, n: Int): PendingIntent {
        val intent = Intent(context, javaClass)
            .setAction(action)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        return PendingIntent.getBroadcast(
            context, id * 10 + n, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    protected fun openCalendar(context: Context, id: Int): PendingIntent {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("content://com.android.calendar/time/${System.currentTimeMillis()}")
        )
        return PendingIntent.getActivity(
            context, id * 10 + 4, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Tints the glass background pieces (fill is only tinted when [fill] is given). */
    protected fun tintGlass(rv: RemoteViews, fill: Int?, ring: Int, glow: Int) {
        if (fill != null) rv.setInt(R.id.bg_fill, "setColorFilter", fill)
        rv.setInt(R.id.bg_ring, "setColorFilter", ring)
        rv.setInt(R.id.bg_glow, "setColorFilter", glow)
    }

    protected fun showToday(rv: RemoteViews, d: Int, dot: Int, halo: Int) {
        rv.setViewVisibility(HALO[d], View.VISIBLE)
        rv.setViewVisibility(DOT[d], View.VISIBLE)
        rv.setInt(HALO[d], "setColorFilter", halo)
        rv.setInt(DOT[d], "setColorFilter", dot)
    }

    companion object {
        val CELLS = intArrayOf(R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5, R.id.c6)
        val HALO = intArrayOf(R.id.h0, R.id.h1, R.id.h2, R.id.h3, R.id.h4, R.id.h5, R.id.h6)
        val DOT = intArrayOf(R.id.p0, R.id.p1, R.id.p2, R.id.p3, R.id.p4, R.id.p5, R.id.p6)
    }
}

// ------------------------------------------------------------------ month styles

class MonthLook(
    val title: Int,
    val day: Int,
    val weekday: Int,
    val arrow: Int,
    val dot: Int,
    val halo: Int,
    val todayText: Int
)

abstract class MonthProvider : BaseProvider() {
    protected abstract val rootLayout: Int
    protected open val showEvents: Boolean = false
    protected abstract fun look(accent: Int, glow: Int): MonthLook
    protected open fun tintBackground(rv: RemoteViews, accent: Int, glow: Int) {}

    override fun render(context: Context, mgr: AppWidgetManager, id: Int) {
        val sizeClass = WidgetSize.sizeClass(mgr, id)
        val rowRes = when (sizeClass) {
            2 -> R.layout.cal_glow_row_small
            3 -> R.layout.cal_glow_row_medium
            else -> R.layout.cal_glow_row_large
        }
        val weekdayRes = when (sizeClass) {
            2 -> R.layout.cal_wd_small
            3 -> R.layout.cal_wd_medium
            else -> R.layout.cal_wd_large
        }
        val accent = accentOf(context)
        val glow = glowOf(accent)
        val look = look(accent, glow)
        val locale = Locale.getDefault()
        val today = LocalDate.now()
        val first = today.withDayOfMonth(1).plusMonths(Prefs.calOffset(context, id).toLong())

        val rv = RemoteViews(context.packageName, rootLayout)
        tintBackground(rv, accent, glow)

        val pattern = if (sizeClass == 2) "MMM yyyy" else "MMMM yyyy"
        rv.setTextViewText(R.id.cal_title, first.format(DateTimeFormatter.ofPattern(pattern, locale)))
        rv.setTextColor(R.id.cal_title, look.title)
        rv.setTextViewTextSize(R.id.cal_title, TypedValue.COMPLEX_UNIT_SP, if (sizeClass == 2) 12f else 15f)
        rv.setTextColor(R.id.cal_prev, look.arrow)
        rv.setTextColor(R.id.cal_next, look.arrow)

        val startDow = if (Prefs.mondayFirst(context)) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
        val lead = (first.dayOfWeek.value - startDow.value + 7) % 7
        val length = first.lengthOfMonth()

        rv.removeAllViews(R.id.cal_grid)

        val weekdays = RemoteViews(context.packageName, weekdayRes)
        for (d in 0 until 7) {
            weekdays.setTextViewText(CELLS[d], startDow.plus(d.toLong()).getDisplayName(TextStyle.NARROW, locale))
            weekdays.setTextColor(CELLS[d], look.weekday)
        }
        rv.addView(R.id.cal_grid, weekdays)

        for (week in 0 until 6) {
            val row = RemoteViews(context.packageName, rowRes)
            for (d in 0 until 7) {
                val day = week * 7 + d - lead + 1
                if (day in 1..length) {
                    row.setTextViewText(CELLS[d], day.toString())
                    if (first.withDayOfMonth(day) == today) {
                        row.setTextColor(CELLS[d], look.todayText)
                        row.setViewVisibility(HALO[d], View.VISIBLE)
                        row.setViewVisibility(DOT[d], View.VISIBLE)
                        row.setInt(HALO[d], "setColorFilter", look.halo)
                        row.setInt(DOT[d], "setColorFilter", look.dot)
                    } else {
                        row.setTextColor(CELLS[d], look.day)
                    }
                } else {
                    row.setTextViewText(CELLS[d], "")
                }
            }
            rv.addView(R.id.cal_grid, row)
        }

        rv.setOnClickPendingIntent(R.id.cal_prev, broadcast(context, id, CalendarWidgetProvider.ACTION_PREV, 1))
        rv.setOnClickPendingIntent(R.id.cal_next, broadcast(context, id, CalendarWidgetProvider.ACTION_NEXT, 2))
        rv.setOnClickPendingIntent(R.id.cal_title, broadcast(context, id, CalendarWidgetProvider.ACTION_RESET, 3))
        rv.setOnClickPendingIntent(R.id.cal_grid, openCalendar(context, id))

        if (showEvents) {
            if (sizeClass >= 4) {
                rv.setViewVisibility(R.id.events_box, View.VISIBLE)
                Events.bindLines(
                    context, rv, Events.upcoming(context, 1, 3),
                    intArrayOf(R.id.ev0, R.id.ev1, R.id.ev2), R.id.ev_hint
                )
                rv.setOnClickPendingIntent(R.id.events_box, openCalendar(context, id))
            } else {
                rv.setViewVisibility(R.id.events_box, View.GONE)
            }
        }
        mgr.updateAppWidget(id, rv)
    }
}

/** Dark glass, glowing edge, glowing today. */
class GlowMonthProvider : MonthProvider() {
    override val rootLayout = R.layout.widget_cal_glass
    override val showEvents = true
    override fun look(accent: Int, glow: Int) = MonthLook(
        title = glow, day = 0xFFF4F4F8.toInt(), weekday = 0xFF9A9DB0.toInt(), arrow = 0xB3FFFFFF.toInt(),
        dot = glow, halo = glow, todayText = Color.WHITE
    )

    override fun tintBackground(rv: RemoteViews, accent: Int, glow: Int) = tintGlass(rv, null, glow, glow)
}

/** Solid accent colour, white today. */
class BoldMonthProvider : MonthProvider() {
    override val rootLayout = R.layout.widget_cal_glass
    override fun look(accent: Int, glow: Int) = MonthLook(
        title = Color.WHITE, day = Color.WHITE, weekday = 0xB3FFFFFF.toInt(), arrow = Color.WHITE,
        dot = Color.WHITE, halo = Color.WHITE, todayText = accent
    )

    override fun tintBackground(rv: RemoteViews, accent: Int, glow: Int) {
        rv.setViewVisibility(R.id.events_box, View.GONE)
        tintGlass(rv, accent, Color.WHITE, Color.WHITE)
    }
}

/** No background at all, for placing straight on the wallpaper. */
class MinimalMonthProvider : MonthProvider() {
    override val rootLayout = R.layout.widget_cal_minimal
    override fun look(accent: Int, glow: Int) = MonthLook(
        title = Color.WHITE, day = Color.WHITE, weekday = 0xB3FFFFFF.toInt(), arrow = Color.WHITE,
        dot = accent, halo = glow, todayText = Color.WHITE
    )
}

// ------------------------------------------------------------------ date card

class DateCardProvider : BaseProvider() {
    override fun render(context: Context, mgr: AppWidgetManager, id: Int) {
        val (wCells, hCells) = WidgetSize.cellsWH(mgr, id)
        val accent = accentOf(context)
        val glow = glowOf(accent)
        val locale = Locale.getDefault()
        val today = LocalDate.now()

        val rv = RemoteViews(context.packageName, R.layout.widget_datecard)
        tintGlass(rv, null, glow, glow)

        rv.setTextViewText(R.id.dc_weekday, today.dayOfWeek.getDisplayName(TextStyle.FULL, locale).uppercase(locale))
        rv.setTextColor(R.id.dc_weekday, glow)
        rv.setTextViewText(R.id.dc_day, today.dayOfMonth.toString())
        val small = minOf(wCells, hCells)
        rv.setTextViewTextSize(R.id.dc_day, TypedValue.COMPLEX_UNIT_SP, if (small <= 2) 48f else if (small == 3) 64f else 78f)
        rv.setTextViewText(R.id.dc_month, today.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)))

        if (hCells >= 3) {
            rv.setViewVisibility(R.id.dc_events, View.VISIBLE)
            Events.bindLines(
                context, rv, Events.upcoming(context, 1, 3).filter { it.date == today },
                intArrayOf(R.id.ev0, R.id.ev1, R.id.ev2), R.id.ev_hint
            )
        } else {
            rv.setViewVisibility(R.id.dc_events, View.GONE)
        }
        rv.setOnClickPendingIntent(R.id.dc_day, openCalendar(context, id))
        rv.setOnClickPendingIntent(R.id.dc_events, openCalendar(context, id))
        mgr.updateAppWidget(id, rv)
    }
}

// ------------------------------------------------------------------ week strip

class WeekStripProvider : BaseProvider() {
    private val weekdayIds = intArrayOf(R.id.w0, R.id.w1, R.id.w2, R.id.w3, R.id.w4, R.id.w5, R.id.w6)

    override fun render(context: Context, mgr: AppWidgetManager, id: Int) {
        val (_, hCells) = WidgetSize.cellsWH(mgr, id)
        val accent = accentOf(context)
        val glow = glowOf(accent)
        val locale = Locale.getDefault()
        val today = LocalDate.now()
        val startDow = if (Prefs.mondayFirst(context)) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
        val weekStart = today.with(TemporalAdjusters.previousOrSame(startDow))

        val rv = RemoteViews(context.packageName, R.layout.widget_week)
        tintGlass(rv, null, glow, glow)

        rv.setTextViewText(R.id.wk_title, today.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)))
        rv.setTextColor(R.id.wk_title, glow)

        for (d in 0 until 7) {
            val date = weekStart.plusDays(d.toLong())
            rv.setTextViewText(weekdayIds[d], date.dayOfWeek.getDisplayName(TextStyle.SHORT, locale))
            rv.setTextViewText(CELLS[d], date.dayOfMonth.toString())
            if (date == today) {
                rv.setTextColor(CELLS[d], Color.WHITE)
                rv.setTextColor(weekdayIds[d], glow)
                showToday(rv, d, glow, glow)
            } else {
                rv.setTextColor(CELLS[d], 0xFFF4F4F8.toInt())
                rv.setTextColor(weekdayIds[d], 0x99FFFFFF.toInt())
                rv.setViewVisibility(HALO[d], View.GONE)
                rv.setViewVisibility(DOT[d], View.GONE)
            }
        }

        if (hCells >= 3) {
            rv.setViewVisibility(R.id.wk_events, View.VISIBLE)
            Events.bindLines(
                context, rv, Events.upcoming(context, 1, 2).filter { it.date == today },
                intArrayOf(R.id.ev0, R.id.ev1), R.id.ev_hint
            )
            rv.setViewVisibility(R.id.ev2, View.GONE)
        } else {
            rv.setViewVisibility(R.id.wk_events, View.GONE)
        }
        rv.setOnClickPendingIntent(R.id.wk_strip, openCalendar(context, id))
        rv.setOnClickPendingIntent(R.id.wk_title, openCalendar(context, id))
        mgr.updateAppWidget(id, rv)
    }
}

// ------------------------------------------------------------------ agenda

class AgendaProvider : BaseProvider() {
    private val rowIds = intArrayOf(R.id.agr0, R.id.agr1, R.id.agr2, R.id.agr3, R.id.agr4, R.id.agr5)
    private val dayIds = intArrayOf(R.id.agd0, R.id.agd1, R.id.agd2, R.id.agd3, R.id.agd4, R.id.agd5)
    private val textIds = intArrayOf(R.id.agt0, R.id.agt1, R.id.agt2, R.id.agt3, R.id.agt4, R.id.agt5)

    override fun render(context: Context, mgr: AppWidgetManager, id: Int) {
        val (_, hCells) = WidgetSize.cellsWH(mgr, id)
        val accent = accentOf(context)
        val glow = glowOf(accent)
        val locale = Locale.getDefault()
        val today = LocalDate.now()

        val rv = RemoteViews(context.packageName, R.layout.widget_agenda)
        tintGlass(rv, null, glow, glow)

        rv.setTextViewText(R.id.ag_date, today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)))
        rv.setTextColor(R.id.ag_sub, glow)
        rv.setTextViewText(R.id.ag_sub, "Upcoming this week")

        val maxRows = when {
            hCells >= 4 -> 6
            hCells == 3 -> 4
            else -> 2
        }
        val items = Events.upcoming(context, 7, maxRows)
        val dayFmt = DateTimeFormatter.ofPattern("EEE d", locale)
        for (i in 0 until 6) {
            if (i < items.size) {
                val item = items[i]
                val label = when (item.date) {
                    today -> "Today"
                    today.plusDays(1) -> "Tomorrow"
                    else -> item.date.format(dayFmt)
                }
                rv.setTextViewText(dayIds[i], label)
                rv.setTextColor(dayIds[i], glow)
                rv.setTextViewText(textIds[i], item.line())
                rv.setViewVisibility(rowIds[i], View.VISIBLE)
            } else {
                rv.setViewVisibility(rowIds[i], View.GONE)
            }
        }
        val hint = when {
            !Events.granted(context) -> context.getString(R.string.hint_allow_calendar)
            items.isEmpty() -> "Nothing coming up this week"
            else -> null
        }
        if (hint != null) {
            rv.setTextViewText(R.id.ag_hint, hint)
            rv.setViewVisibility(R.id.ag_hint, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.ag_hint, View.GONE)
        }
        rv.setOnClickPendingIntent(R.id.ag_date, openCalendar(context, id))
        mgr.updateAppWidget(id, rv)
    }
}
