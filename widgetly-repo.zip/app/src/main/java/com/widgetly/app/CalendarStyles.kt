package com.widgetly.app

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Date
import java.util.Locale

/** Every extra calendar widget design, listed so the app can offer them on the Home tab. */
class StyleInfo(val name: String, val desc: String, val cls: Class<*>, val preview: Int)

object CalendarStyles {
    val LIST = listOf(
        StyleInfo("Glow Month", "Dark glass month, glowing edge and glowing today.", GlowMonthProvider::class.java, R.drawable.preview_glow),
        StyleInfo("Bold Month", "Solid white card with a dark today.", BoldMonthProvider::class.java, R.drawable.preview_bold),
        StyleInfo("Minimal Month", "Transparent, sits right on your wallpaper.", MinimalMonthProvider::class.java, R.drawable.preview_minimal),
        StyleInfo("Date Card", "Big date on dark glass, plus today's events when tall.", DateCardProvider::class.java, R.drawable.preview_datecard),
        StyleInfo("Date Light", "Big date on a white card, plus today's events when tall.", DateLightProvider::class.java, R.drawable.preview_datelight),
        StyleInfo("Date Minimal", "Just a big date, right on your wallpaper.", DateMinimalProvider::class.java, R.drawable.preview_dateminimal),
        StyleInfo("Week Strip", "This week in a glowing strip (4×2).", WeekStripProvider::class.java, R.drawable.preview_week),
        StyleInfo("Agenda", "Your next events this week (4×3).", AgendaProvider::class.java, R.drawable.preview_agenda)
    )

    fun updateAll(c: Context) {
        listOf<BaseProvider>(
            GlowMonthProvider(), BoldMonthProvider(), MinimalMonthProvider(),
            DateCardProvider(), DateLightProvider(), DateMinimalProvider(), WeekStripProvider(), AgendaProvider()
        ).forEach { it.updateOwn(c) }
    }
}

/**
 * One widget can switch design after it is placed: the chosen design is stored per widget id,
 * and every provider renders through here. A widget that was never configured uses the design
 * of the entry it was added from.
 */
object CalendarRenderer {
    const val CLASSIC = 0
    val NAMES = listOf("Classic", "Glow Month", "Bold Month", "Minimal Month", "Date Card", "Week Strip", "Agenda", "Date Light", "Date Minimal")
    val DESCS = listOf(
        "Clean month grid that follows light / dark mode.",
        "Dark glass month with a glowing edge.",
        "Solid white card with a dark today.",
        "Transparent, sits right on your wallpaper.",
        "Big date, plus today's events when tall.",
        "This week in a glowing strip.",
        "Your next events this week.",
        "Big date on a white card.",
        "Just a big date, on your wallpaper."
    )

    private val classic = ClassicMonthProvider()
    private val glow = GlowMonthProvider()
    private val bold = BoldMonthProvider()
    private val minimal = MinimalMonthProvider()
    private val dateCard = DateCardProvider()
    private val week = WeekStripProvider()
    private val agenda = AgendaProvider()
    private val dateLight = DateLightProvider()
    private val dateMinimal = DateMinimalProvider()

    /** Which customisation options make sense for a style. */
    fun hasEvents(style: Int) = style in intArrayOf(0, 1, 4, 5, 7, 8)
    fun hasMonday(style: Int) = style in intArrayOf(0, 1, 2, 3, 5)
    fun hasTextSize(style: Int) = style in intArrayOf(0, 1, 2, 3, 4, 7, 8)

    fun defaultFor(className: String?): Int = when (className?.substringAfterLast('.')) {
        "GlowMonthProvider" -> 1
        "BoldMonthProvider" -> 2
        "MinimalMonthProvider" -> 3
        "DateCardProvider" -> 4
        "WeekStripProvider" -> 5
        "AgendaProvider" -> 6
        "DateLightProvider" -> 7
        "DateMinimalProvider" -> 8
        else -> CLASSIC
    }

    fun styleOf(c: Context, mgr: AppWidgetManager, id: Int): Int {
        val saved = Prefs.calStyle(c, id)
        if (saved in NAMES.indices) return saved
        return defaultFor(mgr.getAppWidgetInfo(id)?.provider?.className)
    }

    fun render(c: Context, mgr: AppWidgetManager, id: Int) {
        when (styleOf(c, mgr, id)) {
            1 -> glow.render(c, mgr, id)
            2 -> bold.render(c, mgr, id)
            3 -> minimal.render(c, mgr, id)
            4 -> dateCard.render(c, mgr, id)
            5 -> week.render(c, mgr, id)
            6 -> agenda.render(c, mgr, id)
            7 -> dateLight.render(c, mgr, id)
            8 -> dateMinimal.render(c, mgr, id)
            else -> classic.render(c, mgr, id)
        }
    }
}

/** Widgets use fixed neutral colours; the app accent colour only applies inside the app. */
internal val NEUTRAL_GLOW: Int = 0xFFE6E8F5.toInt()
internal val DARK_INK: Int = 0xFF14141F.toInt()
internal fun accentOf(@Suppress("UNUSED_PARAMETER") c: Context): Int = NEUTRAL_GLOW
internal fun glowOf(argb: Int): Int = argb

/** Calendar events helper shared by the new widgets. */
object Events {
    class Item(val date: LocalDate, val time: String?, val title: String) {
        fun line(): String = if (time == null) title else "$time  $title"
    }

    fun granted(c: Context) = ContextCompat.checkSelfPermission(
        c, Manifest.permission.READ_CALENDAR
    ) == PackageManager.PERMISSION_GRANTED

    /** Events from today for [days] days, skipping ones that already finished. */
    fun upcoming(c: Context, days: Int, limit: Int): List<Item> {
        if (!granted(c)) return emptyList()
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now()
        val start = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = today.plusDays(days.toLong()).atStartOfDay(zone).toInstant().toEpochMilli()
        val now = System.currentTimeMillis()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, start)
        ContentUris.appendId(b, end)
        val out = ArrayList<Item>()
        try {
            c.contentResolver.query(
                b.build(),
                arrayOf(
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.END,
                    CalendarContract.Instances.ALL_DAY
                ),
                null, null, "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { cur ->
                val tf = DateFormat.getTimeFormat(c)
                while (cur.moveToNext() && out.size < limit) {
                    val title = cur.getString(0)?.takeIf { it.isNotBlank() }
                        ?: c.getString(R.string.event_untitled)
                    val begin = cur.getLong(1)
                    val endMs = cur.getLong(2)
                    val allDay = cur.getInt(3) == 1
                    if (!allDay && endMs < now) continue
                    val date = Instant.ofEpochMilli(begin)
                        .atZone(if (allDay) ZoneOffset.UTC else zone).toLocalDate()
                    out.add(Item(if (date.isBefore(today)) today else date, if (allDay) null else tf.format(Date(begin)), title))
                }
            }
        } catch (e: Exception) {
            // No permission or provider problem: show nothing.
        }
        return out
    }

    /** Fills up to ids.size one-line views and a hint line. */
    fun bindLines(c: Context, rv: RemoteViews, items: List<Item>, ids: IntArray, hintId: Int) {
        ids.forEachIndexed { i, id ->
            if (i < items.size) {
                rv.setTextViewText(id, items[i].line())
                rv.setViewVisibility(id, View.VISIBLE)
            } else {
                rv.setViewVisibility(id, View.GONE)
            }
        }
        val hint = when {
            !granted(c) -> c.getString(R.string.hint_allow_calendar)
            items.isEmpty() -> c.getString(R.string.hint_no_events)
            else -> null
        }
        if (hint != null) {
            rv.setTextViewText(hintId, hint)
            rv.setViewVisibility(hintId, View.VISIBLE)
        } else {
            rv.setViewVisibility(hintId, View.GONE)
        }
    }
}

abstract class BaseProvider : AppWidgetProvider() {

    abstract fun render(context: Context, mgr: AppWidgetManager, id: Int)

    fun updateOwn(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        mgr.getAppWidgetIds(ComponentName(context, javaClass)).forEach { CalendarRenderer.render(context, mgr, it) }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { CalendarRenderer.render(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?
    ) {
        CalendarRenderer.render(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { Prefs.clearCalendar(context, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        when (intent.action) {
            CalendarWidgetProvider.ACTION_PREV,
            CalendarWidgetProvider.ACTION_NEXT,
            CalendarWidgetProvider.ACTION_RESET -> {
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                    val cur = Prefs.calOffset(context, id)
                    val next = when (intent.action) {
                        CalendarWidgetProvider.ACTION_PREV -> cur - 1
                        CalendarWidgetProvider.ACTION_NEXT -> cur + 1
                        else -> 0
                    }
                    Prefs.setCalOffset(context, id, next)
                    CalendarRenderer.render(context, AppWidgetManager.getInstance(context), id)
                }
            }
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> WidgetUpdater.updateAll(context)
        }
    }

    protected fun broadcast(context: Context, id: Int, action: String, n: Int): PendingIntent {
        val intent = Intent(context, CalendarWidgetProvider::class.java)
            .setAction(action)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        return PendingIntent.getBroadcast(
            context, id * 10 + n, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    protected fun openCalendar(context: Context, id: Int): PendingIntent {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("content://com.android.calendar/time/${System.currentTimeMillis()}")
        )
        return PendingIntent.getActivity(
            context, id * 10 + 4, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Tints the glass background pieces (fill is only tinted when [fill] is given). */
    protected fun tintGlass(rv: RemoteViews, fill: Int?, ring: Int, glow: Int) {
        if (fill != null) rv.setInt(R.id.bg_fill, "setColorFilter", fill)
        rv.setInt(R.id.bg_ring, "setColorFilter", ring)
        rv.setInt(R.id.bg_glow, "setColorFilter", glow)
    }

    protected fun showToday(rv: RemoteViews, d: Int, dot: Int, halo: Int) {
        rv.setViewVisibility(HALO[d], View.VISIBLE)
        rv.setViewVisibility(DOT[d], View.VISIBLE)
        rv.setInt(HALO[d], "setColorFilter", halo)
        rv.setInt(DOT[d], "setColorFilter", dot)
    }

    companion object {
        val CELLS = intArrayOf(R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5, R.id.c6)
        val HALO = intArrayOf(R.id.h0, R.id.h1, R.id.h2, R.id.h3, R.id.h4, R.id.h5, R.id.h6)
        val DOT = intArrayOf(R.id.p0, R.id.p1, R.id.p2, R.id.p3, R.id.p4, R.id.p5, R.id.p6)
    }
}

// ------------------------------------------------------------------ month styles

class MonthLook(
    val title: Int,
    val day: Int,
    val weekday: Int,
    val arrow: Int,
    val dot: Int,
    val halo: Int,
    val todayText: Int,
    val ev: Int = Color.WHITE,
    val evDim: Int = 0x99FFFFFF.toInt(),
    val divider: Int = 0x33FFFFFF
)

abstract class MonthProvider : BaseProvider() {
    protected abstract val rootLayout: Int
    protected open val showEvents: Boolean = false
    protected abstract fun look(): MonthLook
    protected open fun tintBackground(rv: RemoteViews) {}

    override fun render(context: Context, mgr: AppWidgetManager, id: Int) {
        val cu = Prefs.custom(context, id)
        val sizeClass = WidgetSize.sizeClass(mgr, id)
        val rowRes = when (sizeClass) {
            2 -> R.layout.cal_glow_row_small
            3 -> R.layout.cal_glow_row_medium
            else -> R.layout.cal_glow_row_large
        }
        val weekdayRes = when (sizeClass) {
            2 -> R.layout.cal_wd_small
            3 -> R.layout.cal_wd_medium
            else -> R.layout.cal_wd_large
        }
        val b = look()
        val look = MonthLook(
            title = cu.text(b.title), day = cu.text(b.day), weekday = cu.faint(b.weekday),
            arrow = cu.dim(b.arrow), dot = cu.hi(b.dot), halo = cu.halo(b.halo),
            todayText = cu.onHi(b.todayText), ev = cu.text(b.ev), evDim = cu.faint(b.evDim),
            divider = b.divider
        )
        val cellSp = when (sizeClass) { 2 -> 8f; 3 -> 10f; else -> 12f }
        val locale = Locale.getDefault()
        val today = LocalDate.now()
        val first = today.withDayOfMonth(1).plusMonths(Prefs.calOffset(context, id).toLong())

        val rv = RemoteViews(context.packageName, rootLayout)
        tintBackground(rv)
        cu.applyBg(rv)

        val pattern = if (sizeClass == 2) "MMM yyyy" else "MMMM yyyy"
        rv.setTextViewText(R.id.cal_title, first.format(DateTimeFormatter.ofPattern(pattern, locale)))
        rv.setTextColor(R.id.cal_title, look.title)
        rv.setTextViewTextSize(R.id.cal_title, TypedValue.COMPLEX_UNIT_SP, cu.size(if (sizeClass == 2) 12f else 15f))
        rv.setTextColor(R.id.cal_prev, look.arrow)
        rv.setTextColor(R.id.cal_next, look.arrow)

        val startDow = if (cu.mondayFirst(context)) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
        val lead = (first.dayOfWeek.value - startDow.value + 7) % 7
        val length = first.lengthOfMonth()

        rv.removeAllViews(R.id.cal_grid)

        val weekdays = RemoteViews(context.packageName, weekdayRes)
        for (d in 0 until 7) {
            weekdays.setTextViewText(CELLS[d], startDow.plus(d.toLong()).getDisplayName(TextStyle.NARROW, locale))
            weekdays.setTextColor(CELLS[d], look.weekday)
            if (cu.scale != 1f) weekdays.setTextViewTextSize(CELLS[d], TypedValue.COMPLEX_UNIT_SP, cu.size(cellSp))
        }
        rv.addView(R.id.cal_grid, weekdays)

        for (week in 0 until 6) {
            val row = RemoteViews(context.packageName, rowRes)
            for (d in 0 until 7) {
                val day = week * 7 + d - lead + 1
                if (day in 1..length) {
                    row.setTextViewText(CELLS[d], day.toString())
                    if (cu.scale != 1f) row.setTextViewTextSize(CELLS[d], TypedValue.COMPLEX_UNIT_SP, cu.size(cellSp))
                    if (first.withDayOfMonth(day) == today) {
                        row.setTextColor(CELLS[d], look.todayText)
                        row.setViewVisibility(HALO[d], View.VISIBLE)
                        row.setViewVisibility(DOT[d], View.VISIBLE)
                        row.setInt(HALO[d], "setColorFilter", look.halo)
                        row.setInt(DOT[d], "setColorFilter", look.dot)
                    } else {
                        row.setTextColor(CELLS[d], look.day)
                    }
                } else {
                    row.setTextViewText(CELLS[d], "")
                }
            }
            rv.addView(R.id.cal_grid, row)
        }

        rv.setOnClickPendingIntent(R.id.cal_prev, broadcast(context, id, CalendarWidgetProvider.ACTION_PREV, 1))
        rv.setOnClickPendingIntent(R.id.cal_next, broadcast(context, id, CalendarWidgetProvider.ACTION_NEXT, 2))
        rv.setOnClickPendingIntent(R.id.cal_title, broadcast(context, id, CalendarWidgetProvider.ACTION_RESET, 3))
        rv.setOnClickPendingIntent(R.id.cal_grid, openCalendar(context, id))

        if (showEvents) {
            if (sizeClass >= 4 && cu.events) {
                rv.setViewVisibility(R.id.events_box, View.VISIBLE)
                Events.bindLines(
                    context, rv, Events.upcoming(context, 1, 3),
                    intArrayOf(R.id.ev0, R.id.ev1, R.id.ev2), R.id.ev_hint
                )
                for (v in intArrayOf(R.id.ev0, R.id.ev1, R.id.ev2)) rv.setTextColor(v, look.ev)
                rv.setTextColor(R.id.ev_hint, look.evDim)
                rv.setInt(R.id.ev_div, "setBackgroundColor", look.divider)
                rv.setOnClickPendingIntent(R.id.events_box, openCalendar(context, id))
            } else {
                rv.setViewVisibility(R.id.events_box, View.GONE)
            }
        }
        mgr.updateAppWidget(id, rv)
    }
}

/** Plain white card, dark today. The default calendar widget. */
class ClassicMonthProvider : MonthProvider() {
    override val rootLayout = R.layout.widget_cal_glass
    override val showEvents = true
    override fun look() = MonthLook(
        title = CLASSIC_INK, day = CLASSIC_INK, weekday = CLASSIC_DIM, arrow = CLASSIC_DIM,
        dot = CLASSIC_INK, halo = 0x00000000, todayText = Color.WHITE,
        ev = CLASSIC_INK, evDim = CLASSIC_DIM, divider = 0x33808098
    )

    override fun tintBackground(rv: RemoteViews) {
        rv.setInt(R.id.bg_fill, "setColorFilter", Color.WHITE)
        rv.setInt(R.id.bg_fill, "setImageAlpha", 255)
        rv.setViewVisibility(R.id.bg_ring, View.GONE)
        rv.setViewVisibility(R.id.bg_glow, View.GONE)
    }
}

private val CLASSIC_INK = 0xFF1B1B2F.toInt()
private val CLASSIC_DIM = 0xFF8A8CA5.toInt()

/** Dark glass, glowing edge, glowing today. */
class GlowMonthProvider : MonthProvider() {
    override val rootLayout = R.layout.widget_cal_glass
    override val showEvents = true
    override fun look() = MonthLook(
        title = NEUTRAL_GLOW, day = 0xFFF4F4F8.toInt(), weekday = 0xFF9A9DB0.toInt(), arrow = 0xB3FFFFFF.toInt(),
        dot = NEUTRAL_GLOW, halo = NEUTRAL_GLOW, todayText = DARK_INK
    )

    override fun tintBackground(rv: RemoteViews) = tintGlass(rv, null, NEUTRAL_GLOW, NEUTRAL_GLOW)
}

/** Solid white card, dark today. */
class BoldMonthProvider : MonthProvider() {
    override val rootLayout = R.layout.widget_cal_glass
    override fun look() = MonthLook(
        title = DARK_INK, day = DARK_INK, weekday = 0x99141420.toInt(), arrow = DARK_INK,
        dot = DARK_INK, halo = 0x33141420, todayText = Color.WHITE
    )

    override fun tintBackground(rv: RemoteViews) {
        rv.setViewVisibility(R.id.events_box, View.GONE)
        tintGlass(rv, 0xFFF4F4F8.toInt(), 0xFFD5D7E4.toInt(), 0x00FFFFFF)
    }
}

/** No background at all, for placing straight on the wallpaper. */
class MinimalMonthProvider : MonthProvider() {
    override val rootLayout = R.layout.widget_cal_minimal
    override fun look() = MonthLook(
        title = Color.WHITE, day = Color.WHITE, weekday = 0xB3FFFFFF.toInt(), arrow = Color.WHITE,
        dot = Color.WHITE, halo = 0x55FFFFFF, todayText = DARK_INK
    )
}

// ------------------------------------------------------------------ date card

open class DateCardProvider : BaseProvider() {
    /** 0 = dark glass, 1 = white card, 2 = no background. */
    protected open val theme = 0

    override fun render(context: Context, mgr: AppWidgetManager, id: Int) {
        val cu = Prefs.custom(context, id)
        val (wCells, hCells) = WidgetSize.cellsWH(mgr, id)
        val locale = Locale.getDefault()
        val today = LocalDate.now()

        val rv = RemoteViews(context.packageName, R.layout.widget_datecard)
        var main = Color.WHITE
        var dim = 0xB3FFFFFF.toInt()
        var weekdayColor = NEUTRAL_GLOW
        when (theme) {
            1 -> {
                tintGlass(rv, 0xFFF4F4F8.toInt(), 0xFFD5D7E4.toInt(), 0x00FFFFFF)
                main = DARK_INK; dim = 0x99141420.toInt(); weekdayColor = 0xFF5B5E78.toInt()
            }
            2 -> {
                rv.setViewVisibility(R.id.bg_fill, View.GONE)
                rv.setViewVisibility(R.id.bg_glow, View.GONE)
                rv.setViewVisibility(R.id.bg_ring, View.GONE)
            }
            else -> tintGlass(rv, null, NEUTRAL_GLOW, NEUTRAL_GLOW)
        }
        cu.applyBg(rv)
        main = cu.text(main); dim = cu.dim(dim); weekdayColor = cu.hi(weekdayColor)

        rv.setTextViewText(R.id.dc_weekday, today.dayOfWeek.getDisplayName(TextStyle.FULL, locale).uppercase(locale))
        rv.setTextColor(R.id.dc_weekday, weekdayColor)
        rv.setTextViewText(R.id.dc_day, today.dayOfMonth.toString())
        rv.setTextColor(R.id.dc_day, main)
        val small = minOf(wCells, hCells)
        rv.setTextViewTextSize(
            R.id.dc_day, TypedValue.COMPLEX_UNIT_SP,
            cu.size(if (small <= 2) 48f else if (small == 3) 64f else 78f)
        )
        rv.setTextViewText(R.id.dc_month, today.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)))
        rv.setTextColor(R.id.dc_month, dim)
        for (v in intArrayOf(R.id.ev0, R.id.ev1, R.id.ev2)) rv.setTextColor(v, main)
        rv.setTextColor(R.id.ev_hint, dim)

        if (hCells >= 3 && cu.events) {
            rv.setViewVisibility(R.id.dc_events, View.VISIBLE)
            Events.bindLines(
                context, rv, Events.upcoming(context, 1, 3).filter { it.date == today },
                intArrayOf(R.id.ev0, R.id.ev1, R.id.ev2), R.id.ev_hint
            )
        } else {
            rv.setViewVisibility(R.id.dc_events, View.GONE)
        }
        rv.setOnClickPendingIntent(R.id.dc_day, openCalendar(context, id))
        rv.setOnClickPendingIntent(R.id.dc_events, openCalendar(context, id))
        mgr.updateAppWidget(id, rv)
    }
}

class DateLightProvider : DateCardProvider() {
    override val theme = 1
}

class DateMinimalProvider : DateCardProvider() {
    override val theme = 2
}

// ------------------------------------------------------------------ week strip

class WeekStripProvider : BaseProvider() {
    private val weekdayIds = intArrayOf(R.id.w0, R.id.w1, R.id.w2, R.id.w3, R.id.w4, R.id.w5, R.id.w6)

    override fun render(context: Context, mgr: AppWidgetManager, id: Int) {
        val cu = Prefs.custom(context, id)
        val (_, hCells) = WidgetSize.cellsWH(mgr, id)
        val hiC = cu.hi(NEUTRAL_GLOW)
        val haloC = cu.halo(NEUTRAL_GLOW)
        val textC = cu.text(0xFFF4F4F8.toInt())
        val dimC = cu.faint(0x99FFFFFF.toInt())
        val locale = Locale.getDefault()
        val today = LocalDate.now()
        val startDow = if (cu.mondayFirst(context)) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
        val weekStart = today.with(TemporalAdjusters.previousOrSame(startDow))

        val rv = RemoteViews(context.packageName, R.layout.widget_week)
        tintGlass(rv, null, NEUTRAL_GLOW, NEUTRAL_GLOW)
        cu.applyBg(rv)

        rv.setTextViewText(R.id.wk_title, today.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)))
        rv.setTextColor(R.id.wk_title, hiC)

        for (d in 0 until 7) {
            val date = weekStart.plusDays(d.toLong())
            rv.setTextViewText(weekdayIds[d], date.dayOfWeek.getDisplayName(TextStyle.SHORT, locale))
            rv.setTextViewText(CELLS[d], date.dayOfMonth.toString())
            if (date == today) {
                rv.setTextColor(CELLS[d], cu.onHi(DARK_INK))
                rv.setTextColor(weekdayIds[d], hiC)
                showToday(rv, d, hiC, haloC)
            } else {
                rv.setTextColor(CELLS[d], textC)
                rv.setTextColor(weekdayIds[d], dimC)
                rv.setViewVisibility(HALO[d], View.GONE)
                rv.setViewVisibility(DOT[d], View.GONE)
            }
        }

        if (hCells >= 3 && cu.events) {
            rv.setViewVisibility(R.id.wk_events, View.VISIBLE)
            Events.bindLines(
                context, rv, Events.upcoming(context, 1, 2).filter { it.date == today },
                intArrayOf(R.id.ev0, R.id.ev1), R.id.ev_hint
            )
            rv.setViewVisibility(R.id.ev2, View.GONE)
            rv.setTextColor(R.id.ev0, textC)
            rv.setTextColor(R.id.ev1, textC)
            rv.setTextColor(R.id.ev_hint, dimC)
        } else {
            rv.setViewVisibility(R.id.wk_events, View.GONE)
        }
        rv.setOnClickPendingIntent(R.id.wk_strip, openCalendar(context, id))
        rv.setOnClickPendingIntent(R.id.wk_title, openCalendar(context, id))
        mgr.updateAppWidget(id, rv)
    }
}

// ------------------------------------------------------------------ agenda

class AgendaProvider : BaseProvider() {
    private val rowIds = intArrayOf(R.id.agr0, R.id.agr1, R.id.agr2, R.id.agr3, R.id.agr4, R.id.agr5)
    private val dayIds = intArrayOf(R.id.agd0, R.id.agd1, R.id.agd2, R.id.agd3, R.id.agd4, R.id.agd5)
    private val textIds = intArrayOf(R.id.agt0, R.id.agt1, R.id.agt2, R.id.agt3, R.id.agt4, R.id.agt5)

    override fun render(context: Context, mgr: AppWidgetManager, id: Int) {
        val cu = Prefs.custom(context, id)
        val (_, hCells) = WidgetSize.cellsWH(mgr, id)
        val hiC = cu.hi(NEUTRAL_GLOW)
        val textC = cu.text(Color.WHITE)
        val dimC = cu.dim(0x99FFFFFF.toInt())
        val locale = Locale.getDefault()
        val today = LocalDate.now()

        val rv = RemoteViews(context.packageName, R.layout.widget_agenda)
        tintGlass(rv, null, NEUTRAL_GLOW, NEUTRAL_GLOW)
        cu.applyBg(rv)

        rv.setTextViewText(R.id.ag_date, today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)))
        rv.setTextColor(R.id.ag_date, textC)
        rv.setTextColor(R.id.ag_sub, hiC)
        rv.setTextViewText(R.id.ag_sub, "Upcoming this week")

        val maxRows = when {
            hCells >= 4 -> 6
            hCells == 3 -> 4
            else -> 2
        }
        val items = Events.upcoming(context, 7, maxRows)
        val dayFmt = DateTimeFormatter.ofPattern("EEE d", locale)
        for (i in 0 until 6) {
            if (i < items.size) {
                val item = items[i]
                val label = when (item.date) {
                    today -> "Today"
                    today.plusDays(1) -> "Tomorrow"
                    else -> item.date.format(dayFmt)
                }
                rv.setTextViewText(dayIds[i], label)
                rv.setTextColor(dayIds[i], hiC)
                rv.setTextViewText(textIds[i], item.line())
                rv.setTextColor(textIds[i], textC)
                rv.setViewVisibility(rowIds[i], View.VISIBLE)
            } else {
                rv.setViewVisibility(rowIds[i], View.GONE)
            }
        }
        val hint = when {
            !Events.granted(context) -> context.getString(R.string.hint_allow_calendar)
            items.isEmpty() -> "Nothing coming up this week"
            else -> null
        }
        if (hint != null) {
            rv.setTextViewText(R.id.ag_hint, hint)
            rv.setTextColor(R.id.ag_hint, dimC)
            rv.setViewVisibility(R.id.ag_hint, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.ag_hint, View.GONE)
        }
        rv.setOnClickPendingIntent(R.id.ag_date, openCalendar(context, id))
        mgr.updateAppWidget(id, rv)
    }
}
