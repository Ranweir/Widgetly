package com.widgetly.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import com.widgetly.app.ui.BubbleTabBar
import com.widgetly.app.ui.CalendarScreen
import com.widgetly.app.ui.HomeScreen
import com.widgetly.app.ui.ImageScreen
import com.widgetly.app.ui.SettingsScreen
import com.widgetly.app.ui.TabItem
import com.widgetly.app.ui.WidgetlyTheme
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppRoot() }
    }
}

private val TABS = listOf(
    TabItem("Home") { rememberVectorPainter(Icons.Filled.Home) },
    TabItem("Photo") { painterResource(R.drawable.ic_image) },
    TabItem("Calendar") { rememberVectorPainter(Icons.Filled.DateRange) },
    TabItem("Settings") { rememberVectorPainter(Icons.Filled.Settings) }
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    var accentIndex by remember { mutableIntStateOf(Prefs.accentIndex(ctx)) }
    var mondayFirst by remember { mutableStateOf(Prefs.mondayFirst(ctx)) }
    val accent = Color(Prefs.ACCENTS[accentIndex])

    val pagerState = rememberPagerState(pageCount = { TABS.size })
    val scope = rememberCoroutineScope()
    fun goTo(i: Int) {
        scope.launch { pagerState.animateScrollToPage(i) }
    }

    WidgetlyTheme(accent = accent) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    beyondBoundsPageCount = 1
                ) { page ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                // Pages shrink and fade a little as they slide away
                                val off = abs(
                                    (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                                ).coerceIn(0f, 1f)
                                alpha = 1f - 0.5f * off
                                val sc = 1f - 0.06f * off
                                scaleX = sc
                                scaleY = sc
                            }
                    ) {
                        when (page) {
                            0 -> HomeScreen(onGo = { goTo(it) })
                            1 -> ImageScreen()
                            2 -> CalendarScreen(mondayFirst = mondayFirst)
                            else -> SettingsScreen(
                                accentIndex = accentIndex,
                                onAccent = {
                                    accentIndex = it
                                    Prefs.setAccentIndex(ctx, it)
                                    WidgetUpdater.updateAll(ctx)
                                },
                                mondayFirst = mondayFirst,
                                onMonday = {
                                    mondayFirst = it
                                    Prefs.setMondayFirst(ctx, it)
                                    WidgetUpdater.updateAll(ctx)
                                }
                            )
                        }
                    }
                }
            }
            BubbleTabBar(
                tabs = TABS,
                position = { pagerState.currentPage + pagerState.currentPageOffsetFraction },
                onSelect = { goTo(it) },
                onDrag = { tabs ->
                    val info = pagerState.layoutInfo
                    pagerState.dispatchRawDelta(tabs * (info.pageSize + info.pageSpacing))
                },
                onDragEnd = {
                    val pos = pagerState.currentPage + pagerState.currentPageOffsetFraction
                    goTo(pos.roundToInt().coerceIn(0, TABS.lastIndex))
                },
                barColor = accent
            )
        }
    }
}
