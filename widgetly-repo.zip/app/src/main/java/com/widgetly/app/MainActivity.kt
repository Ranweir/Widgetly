package com.widgetly.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import com.widgetly.app.ui.BubbleTabBar
import com.widgetly.app.ui.CalendarScreen
import com.widgetly.app.ui.HomeScreen
import com.widgetly.app.ui.ImageScreen
import com.widgetly.app.ui.SettingsScreen
import com.widgetly.app.ui.TabItem
import com.widgetly.app.ui.TelegramDialog
import com.widgetly.app.ui.WidgetlyTheme
import androidx.compose.runtime.saveable.rememberSaveable
import com.widgetly.app.ui.glowColor
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { AppRoot() }
    }
}

private val TABS = listOf(
    TabItem("Home") { rememberVectorPainter(Icons.Filled.Home) },
    TabItem("Photo") { painterResource(R.drawable.ic_image) },
    TabItem("Calendar") { rememberVectorPainter(Icons.Filled.DateRange) },
    TabItem("Settings") { rememberVectorPainter(Icons.Filled.Settings) }
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    var accentIndex by remember { mutableIntStateOf(Prefs.accentIndex(ctx)) }
    var mondayFirst by remember { mutableStateOf(Prefs.mondayFirst(ctx)) }
    val accent = Color(Prefs.ACCENTS[accentIndex])

    val pagerState = rememberPagerState(pageCount = { TABS.size })
    val scope = rememberCoroutineScope()
    var showTelegram by rememberSaveable { mutableStateOf(true) }
    fun goTo(i: Int) {
        scope.launch { pagerState.animateScrollToPage(i) }
    }

    WidgetlyTheme(accent = accent) {
        if (showTelegram) TelegramDialog(onClose = { showTelegram = false })
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .drawBehind {
                    // Soft light-red atmosphere behind everything
                    val g = glowColor(accent)
                    drawRect(
                        Brush.radialGradient(
                            listOf(g.copy(alpha = 0.24f), Color.Transparent),
                            center = Offset(size.width * 0.95f, 0f),
                            radius = size.width * 1.0f
                        )
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(g.copy(alpha = 0.16f), Color.Transparent),
                            center = Offset(0f, size.height),
                            radius = size.width * 1.1f
                        )
                    )
                }
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    beyondBoundsPageCount = 3
                ) { page ->
                    Box(modifier = Modifier.fillMaxSize()) {
                        when (page) {
                            0 -> HomeScreen(onGo = { goTo(it) })
                            1 -> ImageScreen()
                            2 -> CalendarScreen(mondayFirst = mondayFirst)
                            else -> SettingsScreen(
                                accentIndex = accentIndex,
                                onAccent = {
                                    accentIndex = it
                                    Prefs.setAccentIndex(ctx, it)
                                    WidgetUpdater.updateAll(ctx)
                                },
                                mondayFirst = mondayFirst,
                                onMonday = {
                                    mondayFirst = it
                                    Prefs.setMondayFirst(ctx, it)
                                    WidgetUpdater.updateAll(ctx)
                                }
                            )
                        }
                    }
                }
            }
            BubbleTabBar(
                tabs = TABS,
                position = { pagerState.currentPage + pagerState.currentPageOffsetFraction },
                onSelect = { goTo(it) },
                onDrag = { tabs ->
                    val info = pagerState.layoutInfo
                    pagerState.dispatchRawDelta(tabs * (info.pageSize + info.pageSpacing))
                },
                onDragEnd = {
                    val pos = pagerState.currentPage + pagerState.currentPageOffsetFraction
                    goTo(pos.roundToInt().coerceIn(0, TABS.lastIndex))
                },
                accent = accent
            )
        }
    }
}
