package com.widgetly.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import com.widgetly.app.ui.BubbleTabBar
import com.widgetly.app.ui.CalendarScreen
import com.widgetly.app.ui.HomeScreen
import com.widgetly.app.ui.ImageScreen
import com.widgetly.app.ui.SettingsScreen
import com.widgetly.app.ui.TabItem
import com.widgetly.app.ui.WidgetlyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppRoot() }
    }
}

private val TABS = listOf(
    TabItem("Home") { rememberVectorPainter(Icons.Filled.Home) },
    TabItem("Photo") { painterResource(R.drawable.ic_image) },
    TabItem("Calendar") { rememberVectorPainter(Icons.Filled.DateRange) },
    TabItem("Settings") { rememberVectorPainter(Icons.Filled.Settings) }
)

@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    var accentIndex by remember { mutableIntStateOf(Prefs.accentIndex(ctx)) }
    var mondayFirst by remember { mutableStateOf(Prefs.mondayFirst(ctx)) }
    var tab by rememberSaveable { mutableStateOf(0) }
    val accent = Color(Prefs.ACCENTS[accentIndex])

    WidgetlyTheme(accent = accent) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        (fadeIn(tween(300)) + slideInHorizontally(tween(320)) { it / 6 * dir }) togetherWith
                            (fadeOut(tween(160)) + slideOutHorizontally(tween(320)) { -it / 6 * dir })
                    },
                    label = "page"
                ) { page ->
                    when (page) {
                        0 -> HomeScreen(onGo = { tab = it })
                        1 -> ImageScreen()
                        2 -> CalendarScreen(mondayFirst = mondayFirst)
                        else -> SettingsScreen(
                            accentIndex = accentIndex,
                            onAccent = {
                                accentIndex = it
                                Prefs.setAccentIndex(ctx, it)
                                WidgetUpdater.updateAll(ctx)
                            },
                            mondayFirst = mondayFirst,
                            onMonday = {
                                mondayFirst = it
                                Prefs.setMondayFirst(ctx, it)
                                WidgetUpdater.updateAll(ctx)
                            }
                        )
                    }
                }
            }
            BubbleTabBar(
                tabs = TABS,
                selected = tab,
                onSelect = { tab = it },
                barColor = accent
            )
        }
    }
}
