package com.widgetly.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import kotlin.math.abs
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class TabItem(val label: String, val icon: @Composable () -> Painter)

/**
 * Liquid bubble tab bar.
 *
 * Switching tab plays three steps: the bubble shrinks into the bar, the dip
 * (now shallow) slides to the new tab, then the bubble pops back up with a spring.
 * You can also press and slide the bubble; it snaps to the nearest tab on release.
 *
 * Everything (bar, dip, bubble, icons) is drawn in ONE Canvas and the animated
 * values are only read while drawing, so nothing recomposes during the animation.
 */
@Composable
fun BubbleTabBar(
    tabs: List<TabItem>,
    selected: Int,
    onSelect: (Int) -> Unit,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val bottomInset = with(density) { WindowInsets.navigationBars.getBottom(this).toDp() }
    val topPad = 32.dp
    val tabAreaHeight = 60.dp
    val n = tabs.size
    val painters = tabs.map { it.icon() }
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentSelected by rememberUpdatedState(selected)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(topPad + tabAreaHeight + bottomInset)
    ) {
        val tw = with(density) { maxWidth.toPx() } / n

        // x = centre of the dip/bubble, pop = 0 (bubble hidden, shallow dip) .. 1 (bubble out)
        val x = remember { Animatable(tw * (selected + 0.5f)) }
        val pop = remember { Animatable(1f) }
        var dragging by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()

        LaunchedEffect(selected, tw, dragging) {
            if (dragging) return@LaunchedEffect
            val target = tw * (selected + 0.5f)
            if (abs(x.value - target) > tw * 0.6f) {
                // Far jump: shrink -> slide -> pop
                pop.animateTo(0f, tween(140, easing = FastOutSlowInEasing))
                x.animateTo(target, tween(300, easing = FastOutSlowInEasing))
                pop.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 380f))
            } else {
                // Short move (e.g. after a drag): just settle
                coroutineScope {
                    launch {
                        x.animateTo(
                            target,
                            spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium)
                        )
                    }
                    launch {
                        pop.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 380f))
                    }
                }
            }
        }

        Canvas(modifier = Modifier.matchParentSize()) {
            val cx = x.value
            val p = pop.value.coerceAtLeast(0f)

            val top = topPad.toPx()
            val r = 26.dp.toPx()
            val gap = 3.dp.toPx()
            val shallow = 6.dp.toPx()
            val fullDepth = r + gap + 6.dp.toPx()
            val depth = lerp(shallow, fullDepth, p)
            val half = lerp(34.dp.toPx(), 50.dp.toPx(), p.coerceAtMost(1.1f))

            val x0 = cx - half
            val x1 = cx + half

            // Bar with the liquid dip
            val path = Path().apply {
                moveTo(0f, top)
                lineTo(maxOf(0f, x0), top)
                cubicTo(x0 + half * 0.35f, top, cx - half * 0.55f, top + depth, cx, top + depth)
                cubicTo(cx + half * 0.55f, top + depth, x1 - half * 0.35f, top, x1, top)
                lineTo(size.width, top)
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(path, barColor)

            // Icons on the bar: they dim when the dip is near them
            val iconSize = 24.dp.toPx()
            val iconCy = top + tabAreaHeight.toPx() / 2f
            for (i in 0 until n) {
                val iconCx = tw * (i + 0.5f)
                val near = 1f - (abs(cx - iconCx) / (tw * 0.55f)).coerceIn(0f, 1f)
                val a = 1f - near * (0.35f + 0.65f * p.coerceAtMost(1f))
                translate(iconCx - iconSize / 2f, iconCy - iconSize / 2f) {
                    with(painters[i]) {
                        draw(Size(iconSize, iconSize), a, ColorFilter.tint(Color.White))
                    }
                }
            }

            // Bubble (same colour as the bar, sits in the dip with a thin gap)
            val bubbleR = r * p
            if (bubbleR > 0.5f) {
                val cy = top + depth - gap - bubbleR
                drawCircle(barColor, bubbleR, Offset(cx, cy))

                val iconA = ((p - 0.3f) / 0.7f).coerceIn(0f, 1f)
                if (iconA > 0f) {
                    val shown = (cx / tw).toInt().coerceIn(0, n - 1)
                    val s = 26.dp.toPx() * p.coerceAtMost(1.1f)
                    translate(cx - s / 2f, cy - s / 2f) {
                        with(painters[shown]) {
                            draw(Size(s, s), iconA, ColorFilter.tint(Color.White))
                        }
                    }
                }
            }
        }

        // Transparent touch layer (doesn't move, so drag deltas stay exact)
        Box(
            modifier = Modifier
                .matchParentSize()
                .pointerInput(n, tw) {
                    detectTapGestures { pos ->
                        currentOnSelect((pos.x / tw).toInt().coerceIn(0, n - 1))
                    }
                }
                .pointerInput(n, tw) {
                    var dragX = 0f
                    fun finish() {
                        val idx = (dragX / tw).toInt().coerceIn(0, n - 1)
                        dragging = false
                        if (idx != currentSelected) currentOnSelect(idx)
                    }
                    detectHorizontalDragGestures(
                        onDragStart = {
                            dragX = x.value
                            dragging = true
                            scope.launch {
                                x.stop()
                                pop.animateTo(1f, tween(120))
                            }
                        },
                        onDragEnd = { finish() },
                        onDragCancel = { finish() },
                        onHorizontalDrag = { change, delta ->
                            change.consume()
                            dragX = (dragX + delta).coerceIn(tw * 0.5f, tw * (n - 0.5f))
                            scope.launch { x.snapTo(dragX) }
                        }
                    )
                }
        )
    }
}
