package com.widgetly.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class TabItem(val label: String, val icon: @Composable () -> Painter)

/**
 * Bottom bar with a white bubble that springs to the selected tab.
 * The bar has a curved dip that follows the bubble; the selected icon
 * lives inside the bubble, the other icons fade in on the bar.
 */
@Composable
fun BubbleTabBar(
    tabs: List<TabItem>,
    selected: Int,
    onSelect: (Int) -> Unit,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val bottomInset = with(density) { WindowInsets.navigationBars.getBottom(this).toDp() }
    val topPad = 20.dp
    val tabAreaHeight = 60.dp
    val bubbleSize = 54.dp

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(topPad + tabAreaHeight + bottomInset)
    ) {
        val widthPx = with(density) { maxWidth.toPx() }
        val tabWidth = widthPx / tabs.size
        val centerX by animateFloatAsState(
            targetValue = tabWidth * (selected + 0.5f),
            animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow),
            label = "bubbleX"
        )
        val topPx = with(density) { topPad.toPx() }
        val depth = with(density) { 30.dp.toPx() }
        val half = with(density) { 42.dp.toPx() }

        // Bar with the moving dip
        Canvas(modifier = Modifier.matchParentSize()) {
            val cx = centerX
            val x0 = cx - half
            val x1 = cx + half
            val path = Path().apply {
                moveTo(0f, topPx)
                lineTo(maxOf(0f, x0), topPx)
                cubicTo(x0 + half * 0.35f, topPx, cx - half * 0.55f, topPx + depth, cx, topPx + depth)
                cubicTo(cx + half * 0.55f, topPx + depth, x1 - half * 0.35f, topPx, x1, topPx)
                lineTo(size.width, topPx)
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(path, barColor)
        }

        // Icons on the bar (the selected one fades out, the bubble shows it instead)
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(y = topPad)
                .fillMaxWidth()
                .height(tabAreaHeight)
        ) {
            tabs.forEachIndexed { index, tab ->
                val iconAlpha by animateFloatAsState(
                    targetValue = if (index == selected) 0f else 1f,
                    label = "tabAlpha$index"
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = tab.icon(),
                        contentDescription = tab.label,
                        tint = Color.White,
                        modifier = Modifier
                            .size(24.dp)
                            .alpha(iconAlpha)
                    )
                }
            }
        }

        // The bubble
        val bubblePx = with(density) { bubbleSize.toPx() }
        val bubbleTop = with(density) { 2.dp.roundToPx() }
        Box(
            modifier = Modifier
                .offset { IntOffset((centerX - bubblePx / 2f).roundToInt(), bubbleTop) }
                .size(bubbleSize)
                .shadow(8.dp, CircleShape)
                .background(Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = selected, label = "bubbleIcon") { index ->
                Icon(
                    painter = tabs[index].icon(),
                    contentDescription = tabs[index].label,
                    tint = barColor,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}
