package com.widgetly.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import kotlin.math.abs
import kotlin.math.roundToInt

class TabItem(val label: String, val icon: @Composable () -> Painter)

/**
 * Liquid bubble tab bar, driven by the pager.
 *
 * [position] is the continuous page position (0f..n-1f), e.g. currentPage + offsetFraction.
 * The bubble sits on the tab when position is a whole number; while the pages move between
 * two tabs it shrinks into the bar and the dip slides along, then pops back out on arrival.
 * Pressing and sliding the bubble calls [onDrag] (in tab widths) so the pages follow your finger;
 * [onDragEnd] lets the caller settle on the nearest tab.
 *
 * Everything is drawn in ONE Canvas and [position] is only read while drawing,
 * so nothing recomposes during the animation.
 */
@Composable
fun BubbleTabBar(
    tabs: List<TabItem>,
    position: () -> Float,
    onSelect: (Int) -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val bottomInset = with(density) { WindowInsets.navigationBars.getBottom(this).toDp() }
    val topPad = 32.dp
    val tabAreaHeight = 60.dp
    val n = tabs.size
    val painters = tabs.map { it.icon() }
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentOnDrag by rememberUpdatedState(onDrag)
    val currentOnDragEnd by rememberUpdatedState(onDragEnd)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(topPad + tabAreaHeight + bottomInset)
    ) {
        val tw = with(density) { maxWidth.toPx() } / n

        Canvas(modifier = Modifier.matchParentSize()) {
            val pos = position().coerceIn(0f, (n - 1).toFloat())
            val cx = tw * (pos + 0.5f)

            // 1 when the bubble rests on a tab, 0 when halfway between two tabs
            val d = abs(pos - pos.roundToInt())
            val lin = (1f - d * 3f).coerceIn(0f, 1f)
            val p = lin * lin * (3f - 2f * lin)

            val top = topPad.toPx()
            val r = 26.dp.toPx()
            val gap = 3.dp.toPx()
            val shallow = 6.dp.toPx()
            val fullDepth = r + gap + 6.dp.toPx()
            val depth = lerp(shallow, fullDepth, p)
            val half = lerp(34.dp.toPx(), 50.dp.toPx(), p)

            val x0 = cx - half
            val x1 = cx + half

            // Bar with the liquid dip
            val path = Path().apply {
                moveTo(0f, top)
                lineTo(maxOf(0f, x0), top)
                cubicTo(x0 + half * 0.35f, top, cx - half * 0.55f, top + depth, cx, top + depth)
                cubicTo(cx + half * 0.55f, top + depth, x1 - half * 0.35f, top, x1, top)
                lineTo(size.width, top)
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(path, barColor)

            // Icons on the bar: they dim when the dip is near them
            val iconSize = 24.dp.toPx()
            val iconCy = top + tabAreaHeight.toPx() / 2f
            for (i in 0 until n) {
                val iconCx = tw * (i + 0.5f)
                val near = 1f - (abs(cx - iconCx) / (tw * 0.55f)).coerceIn(0f, 1f)
                val a = 1f - near * (0.35f + 0.65f * p)
                translate(iconCx - iconSize / 2f, iconCy - iconSize / 2f) {
                    with(painters[i]) {
                        draw(Size(iconSize, iconSize), a, ColorFilter.tint(Color.White))
                    }
                }
            }

            // Bubble (same colour as the bar, sits in the dip with a thin gap)
            val bubbleR = r * p
            if (bubbleR > 0.5f) {
                val cy = top + depth - gap - bubbleR
                drawCircle(barColor, bubbleR, Offset(cx, cy))

                val iconA = ((p - 0.3f) / 0.7f).coerceIn(0f, 1f)
                if (iconA > 0f) {
                    val shown = pos.roundToInt().coerceIn(0, n - 1)
                    val s = 26.dp.toPx() * p
                    translate(cx - s / 2f, cy - s / 2f) {
                        with(painters[shown]) {
                            draw(Size(s, s), iconA, ColorFilter.tint(Color.White))
                        }
                    }
                }
            }
        }

        // Transparent touch layer (doesn't move, so drag deltas stay exact)
        Box(
            modifier = Modifier
                .matchParentSize()
                .pointerInput(n, tw) {
                    detectTapGestures { pos ->
                        currentOnSelect((pos.x / tw).toInt().coerceIn(0, n - 1))
                    }
                }
                .pointerInput(n, tw) {
                    detectHorizontalDragGestures(
                        onDragEnd = { currentOnDragEnd() },
                        onDragCancel = { currentOnDragEnd() },
                        onHorizontalDrag = { change, delta ->
                            change.consume()
                            currentOnDrag(delta / tw)
                        }
                    )
                }
        )
    }
}
