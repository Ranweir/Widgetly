package com.widgetly.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp as lerpColor
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import kotlin.math.abs
import kotlin.math.roundToInt

class TabItem(val label: String, val icon: @Composable () -> Painter)

/**
 * Liquid bubble tab bar, driven by the pager.
 *
 * [position] is the continuous page position (0f..n-1f), e.g. currentPage + offsetFraction.
 * The bubble sits on the tab when position is a whole number; while the pages move between
 * two tabs it shrinks into the bar and the dip slides along, then pops back out on arrival.
 * Pressing and sliding the bubble calls [onDrag] (in tab widths) so the pages follow your finger;
 * [onDragEnd] lets the caller settle on the nearest tab.
 *
 * Everything is drawn in ONE Canvas and [position] is only read while drawing,
 * so nothing recomposes during the animation.
 */
@Composable
fun BubbleTabBar(
    tabs: List<TabItem>,
    position: () -> Float,
    onSelect: (Int) -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val bottomInset = with(density) { WindowInsets.navigationBars.getBottom(this).toDp() }
    val topPad = 28.dp        // head-room for the bubble
    val barHeight = 64.dp
    val sideMargin = 14.dp
    val bottomGap = 10.dp
    val cornerRadius = 28.dp
    val dipHalf = 50.dp   // room each side of a tab centre; keeps the notch off the corners
    val n = tabs.size
    val painters = tabs.map { it.icon() }
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentOnDrag by rememberUpdatedState(onDrag)
    val currentOnDragEnd by rememberUpdatedState(onDragEnd)

    // Allocated once, reused every frame
    val path = remember { Path() }
    val white = remember { ColorFilter.tint(Color.White) }
    val glow = remember(accent) { glowColor(accent) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(topPad + barHeight + bottomGap + bottomInset)
    ) {
        val marginPx = with(density) { sideMargin.toPx() }
        val cornerPx = with(density) { cornerRadius.toPx() }
        val halfFullPx = with(density) { dipHalf.toPx() }
        val widthPx = with(density) { maxWidth.toPx() }
        // First/last tab centres are inset so the dip never touches the rounded corners
        val cxMin = marginPx + cornerPx + halfFullPx
        val cxMax = widthPx - marginPx - cornerPx - halfFullPx
        val tw = if (n > 1) (cxMax - cxMin) / (n - 1) else 1f   // distance between tabs

        Canvas(modifier = Modifier.matchParentSize()) {
            val pos = position().coerceIn(0f, (n - 1).toFloat())
            val cx = cxMin + tw * pos

            // 1 when the bubble rests on a tab, 0 when halfway between two tabs
            val d = abs(pos - pos.roundToInt())
            val lin = (1f - d * 3f).coerceIn(0f, 1f)
            val p = lin * lin * (3f - 2f * lin)

            val left = marginPx
            val right = size.width - marginPx
            val top = topPad.toPx()
            val bottom = top + barHeight.toPx()
            val cr = cornerPx

            val r = 26.dp.toPx()
            val gap = 3.dp.toPx()
            val shallow = 6.dp.toPx()
            val fullDepth = r + gap + 6.dp.toPx()
            val depth = lerp(shallow, fullDepth, p)
            // Notch = circle concentric with the bubble (so a thin ring of background shows
            // all around it), joined to the bar top by smooth shoulders. At p = 0 the same
            // shape flattens into a shallow dish, so the morph between the two is continuous.
            val k = 0.5523f
            val rn = lerp(20.dp.toPx(), r + gap, p)           // notch radius
            val e = lerp(depth * 0.45f, 6.dp.toPx(), p)       // widest point, below the bar top
            val f = lerp(16.dp.toPx(), 12.dp.toPx(), p)       // shoulder length
            val wd = rn + f
            val ly = top + e
            val hv = depth - e

            path.rewind()
            path.moveTo(left + cr, top)
            path.lineTo(cx - wd, top)
            path.cubicTo(cx - wd + f * 0.7f, top, cx - rn, ly - e * 0.7f, cx - rn, ly)
            path.cubicTo(cx - rn, ly + k * hv, cx - k * rn, top + depth, cx, top + depth)
            path.cubicTo(cx + k * rn, top + depth, cx + rn, ly + k * hv, cx + rn, ly)
            path.cubicTo(cx + rn, ly - e * 0.7f, cx + wd - f * 0.7f, top, cx + wd, top)
            path.lineTo(right - cr, top)
            path.arcTo(Rect(right - 2 * cr, top, right, top + 2 * cr), 270f, 90f, false)
            path.lineTo(right, bottom - cr)
            path.arcTo(Rect(right - 2 * cr, bottom - 2 * cr, right, bottom), 0f, 90f, false)
            path.lineTo(left + cr, bottom)
            path.arcTo(Rect(left, bottom - 2 * cr, left + 2 * cr, bottom), 90f, 90f, false)
            path.lineTo(left, top + cr)
            path.arcTo(Rect(left, top, left + 2 * cr, top + 2 * cr), 180f, 90f, false)
            path.close()

            // Light halo around the whole bar (bright, not a dark shadow): wide faint strokes first
            val halo = 9
            for (i in halo downTo 1) {
                val t = i / halo.toFloat()
                drawPath(
                    path,
                    glow.a(0.07f + 0.10f * (1f - t) * (1f - t)),
                    style = Stroke(width = 2.dp.toPx() + 30.dp.toPx() * t, join = StrokeJoin.Round)
                )
            }
            // Glass body
            drawPath(
                path,
                Brush.verticalGradient(
                    listOf(Color(0xFF232532), Color(0xFF12131B)),
                    startY = top,
                    endY = bottom
                )
            )
            drawPath(path, glow.a(0.10f))
            // Glowing edge: white highlight on top, bright accent at the bottom
            drawPath(
                path,
                Brush.verticalGradient(
                    listOf(Color.White.a(0.40f), glow.a(0.55f), glow),
                    startY = top,
                    endY = bottom
                ),
                style = Stroke(width = 1.5.dp.toPx(), join = StrokeJoin.Round)
            )
            // Bloom on the bottom edge, following the selected tab
            bottomBloom(glow, 1.1f * (0.5f + 0.5f * p), cx, bottom, tw * 0.75f, 20.dp.toPx())

            // Icons on the bar: they dim when the dip is near them
            val iconSize = 24.dp.toPx()
            val iconCy = (top + bottom) / 2f
            for (i in 0 until n) {
                val iconCx = cxMin + tw * i
                val near = 1f - (abs(cx - iconCx) / (tw * 0.55f)).coerceIn(0f, 1f)
                val a = (1f - near * (0.35f + 0.65f * p)) * 0.72f
                translate(iconCx - iconSize / 2f, iconCy - iconSize / 2f) {
                    with(painters[i]) { draw(Size(iconSize, iconSize), a, white) }
                }
            }

            // Bubble (same colour as the bar, sits in the dip with a thin gap)
            val bubbleR = r * p
            if (bubbleR > 0.5f) {
                val cy = top + depth - gap - bubbleR
                for (i in 6 downTo 1) {
                    val t = i / 6f
                    drawCircle(
                        glow.a((0.12f + 0.20f * (1f - t) * (1f - t)) * p),
                        bubbleR + 2.dp.toPx() + 14.dp.toPx() * t,
                        Offset(cx, cy)
                    )
                }
                drawCircle(
                    Brush.radialGradient(
                        listOf(lerpColor(accent, Color.White, 0.45f), accent),
                        center = Offset(cx, cy - bubbleR * 0.3f),
                        radius = bubbleR * 1.3f
                    ),
                    bubbleR,
                    Offset(cx, cy)
                )
                drawCircle(Color.White.a(0.55f), bubbleR, Offset(cx, cy), style = Stroke(1.dp.toPx()))

                val iconA = ((p - 0.3f) / 0.7f).coerceIn(0f, 1f)
                if (iconA > 0f) {
                    val shown = pos.roundToInt().coerceIn(0, n - 1)
                    val s = 26.dp.toPx() * p
                    translate(cx - s / 2f, cy - s / 2f) {
                        with(painters[shown]) { draw(Size(s, s), iconA, white) }
                    }
                }
            }
        }

        // Transparent touch layer (doesn't move, so drag deltas stay exact)
        Box(
            modifier = Modifier
                .matchParentSize()
                .pointerInput(n, tw, cxMin) {
                    detectTapGestures { pos ->
                        currentOnSelect(((pos.x - cxMin) / tw).roundToInt().coerceIn(0, n - 1))
                    }
                }
                .pointerInput(n, tw, cxMin) {
                    detectHorizontalDragGestures(
                        onDragEnd = { currentOnDragEnd() },
                        onDragCancel = { currentOnDragEnd() },
                        onHorizontalDrag = { change, delta ->
                            change.consume()
                            currentOnDrag(delta / tw)
                        }
                    )
                }
        )
    }
}
