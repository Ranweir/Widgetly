# Widgetly

Android app with one empty home-screen widget that the app fills for you.

1. Long-press your home screen, open Widgets, and drag out the single **Widgetly** widget. It stays empty.
2. Open the app and tap **Add** on any calendar style (Classic, Glow, Bold, Minimal, Date Card / Light / Minimal, Week Strip, Agenda) or on the Photo widget. It fills the empty widget. If no empty widget is free, the app asks the launcher to add one.
3. Long-press a filled widget and choose **Reconfigure** (Android 12+) to change its style, background colour and opacity, text colour, today highlight, text size, week start and whether today's events show, or to empty it again.

Every widget can be 2×2 up to 4×4. Accent colour applies to the app only; widgets use neutral colours unless you customise them.

## Get the APK (GitHub Actions)

1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Push to `main`. The **Build APK** workflow starts automatically (or run it from the Actions tab).
3. When it finishes, open the run and download the **widgetly-debug-apk** artifact. Unzip it and install `app-debug.apk` on your phone.

## Open in Android Studio

Open this folder in Android Studio (Koala or newer) and let Gradle sync, then Run.

## Rename the app

- App name: `app/src/main/res/values/strings.xml` (`app_name`)
- Package / application id: `namespace` and `applicationId` in `app/build.gradle.kts`, plus the `package` lines in the Kotlin files and the `com.widgetly.app.ImageConfigActivity` reference in `res/xml/image_widget_info.xml`

## Stack

Kotlin, Jetpack Compose (Material 3), classic `AppWidgetProvider` + `RemoteViews`, minSdk 26, compileSdk 34.
