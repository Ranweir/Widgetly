# Widgetly

Android app with two home-screen widgets, each usable from 2×2 up to 4×4:

- **Calendar widget** – month grid with today highlighted, ‹ › to change month, tap the title to jump back to today. The 4×4 size also lists today's events (needs calendar permission).
- **Photo widget** – pick a photo from your gallery (system photo picker, no storage permission). Tap a widget on the home screen to give it its own photo. Fill/Fit and corner radius are set in the app.

The app has four tabs with an animated bubble tab bar: **Home, Photo, Calendar, Settings**. Accent colour and "week starts on Monday" apply to the app and all widgets.

## Get the APK (GitHub Actions)

1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Push to `main`. The **Build APK** workflow starts automatically (or run it from the Actions tab).
3. When it finishes, open the run and download the **widgetly-debug-apk** artifact. Unzip it and install `app-debug.apk` on your phone.

## Open in Android Studio

Open this folder in Android Studio (Koala or newer) and let Gradle sync, then Run.

## Rename the app

- App name: `app/src/main/res/values/strings.xml` (`app_name`)
- Package / application id: `namespace` and `applicationId` in `app/build.gradle.kts`, plus the `package` lines in the Kotlin files and the `com.widgetly.app.ImageConfigActivity` reference in `res/xml/image_widget_info.xml`

## Stack

Kotlin, Jetpack Compose (Material 3), classic `AppWidgetProvider` + `RemoteViews`, minSdk 26, compileSdk 34.
